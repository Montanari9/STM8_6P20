/********************  (c) 2006 STMicroelectronics  **************************
*  Project   : 
*  Filename  : rcontrol_rx.c
*  Author    : Roberto Pieruci
*         
*  Compiler  : Cosmic ANSI-C
*  CPU       : ST7FLITE	
*****************************  File Contents  ********************************
*									     *
*  Remote Control RF - Reception Routines	      			     *
*									     *
******************************  Description  *********************************
*                                                                            *
*                                                                            *
*                                                                            *
**************************  Update Information  ******************************
*									     *
*  Ed. Date      Own Modification					     *
*  --- --------- ---  -----------------------------------------------------  *
*  001 Feb/15/05 RCP creation						     *
*  002 Nov/30/06 RCP improved						     *
*****************************************************************************/

/*************************  General Include Files  **************************/
#include "stm8s_conf.h"
#include "user_defs.h"		// User definitions
#include "timingsLit_setup.h"	// System Clock Setup

/****************************************************************************/

/***********************  Application Include Files  ************************/     

#include "routines.h"
#include "hw_setup.h"
#define	RCONTROL_RX
#include "rcontrol_rx.h"
#undef RCONTROL_RX
#include "flash_eeprom.h"
#include "interrupt.h"
#include "display.h"

RecFrame RCFrame_temp;
/****************************************************************************/

void EvaluateRemoteControlFrame (void)
/*****************************************************************************
	FUNCTION     : EvaluateRemoteControlFrame ()
	DESCRIPTION  : This routine manipulates the Remote Control Frame 
		captured by Interrup ATR. Then, if the frame is valid, a copy 
		of RC Frame is available with respective flags. It also finds
		a Frame inside Memory.
		This routine also features previous Serial number detection 
		to avoid excessive find/decription for each reception.
	ARGUMENTS    : None
	RETURN VALUE : None  
*****************************************************************************/
{
  signed char	j;
	
  
  // suppose Frame not valid
  RC_Frame_Valid =  FALSE;
  // Check if timeout of reception
  if (RC_Timeout && !--RC_Timeout)	// timeout
  {
    // clear Previous vars of RC
    RC_Frame_Incoming = FALSE;
    //RC_Keys.byte = 0;
  }
  // Chech if Frame is ready
  if (!RC_Input_Ready)	// RControl Frame NOT Ready
    return;	

  // RControl Frame Ready
  disableInterrupts();		// avoid changes in RCFrame_Input
  if (RC_Input_Changing)	// can not use this frame	
  {
    enableInterrupts();
    return;
  }

  // RControl Frame Ready
  // Copy including Anticode flags
  RCFrame_temp = RCFrame_Input;	// Frame 3 bytes + Anticode
  RC_Input_Ready = FALSE;	// indicates Frame copied
  enableInterrupts();

  // Check Anticode
  if (RCFrame_temp.Anticode[0] != ANTICODE)   // Frame NOT valid
    return;

  // Frame is Valid; belongs to the system
  RC_Frame_Valid =  TRUE;
  RC_Frame_Incoming = TRUE;
	if (Mode == MODE_INITIAL)		//timeout longo para filtro
		RC_Timeout = TIME_OUT_RC;	// set new frame overflow time
	else	//timeout rapido para mover display
		RC_Timeout = TIME_OUT_RC1;	// set new frame overflow time
  RCFrame_Copy = RCFrame_temp;
  
  // Uses new Frame
  RC_Keys.byte = (char)(RCFrame_Copy.Data.Button & 0b11000000);	// switches copied
  RCFrame_Copy.Data.Serial[0] &= 0b00111111;		// pure serial number
  // Check if the same previous CR
  RC_Frame_Same = TRUE;	// suppose same previous frame
  for (j = 2; j >= 0; j--)
  {
    if (RCFrame_Copy.Data.Serial[j] != RCFrame_Copy_Previous.Data.Serial[j])
    {
      RC_Frame_Same = FALSE;
      RCFrame_Copy_Previous.Data.Serial[j] = RCFrame_Copy.Data.Serial[j];//update
    }
  }
  // Find inside Memory
  if (!RC_Frame_Same)
	{
		RC_Keys_Copy = RC_Keys;		// initiate with pressed keys
    RCFrame_Address = FindRControlInMem(0);	// search
	}
	else
	{
		RC_Keys_Copy.byte |= RC_Keys.byte;		// accumulate pressed keys
	}
}

void GetRControlFrame (void)
/*****************************************************************************
	FUNCTION     : GetRControlFrame ()
	DESCRIPTION  : This routine captures/filters Remote Control Frames
		from the Input pin. It is called from Interrupt ART overflow. 
		Interrupt time 18.5usecs max
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  u8 register tmp;
  // Capture Rx Input bit into RxIn byte
  if (!RxPin)				// Put bit into Carry
    CountLow++;				// If 0, increases Zero counter
  _asm("rlc a", RxIn);			// Save as bit0; previous is bit1 now
  RxIn = (char)_asm("and a,#3");	// Mask previous and current Rx bits

  if (RxIn != 0b10)			// check if falling edge
  {	// falling edge not found
    CountPer++;				// increases period counter
    // Overflow checks
    if ( (CountPer > Per_Max) )	// error
		{
			StatusRx = OVERPERIOD;
		}
  } 
  else
  {	// falling edge found!
    // **************** Start Switch **************** //
		switch (StatusRx)
    {
      case HEADER:
      {
				// Check Header timing min
				if ( (CountLow < NUM_PILOT_MIN) || (CountPer < NUM_HEADER_MIN) )	//error
				{
					//RC_Positioning();
					goto reset_RC;
					break;
				}
				CountHigh = (char)(CountPer - CountLow);
				if ( (CountHigh < NUM_CK_MIN) || (CountHigh > NUM_CK_MAX) )		//error
				{
					//RC_Positioning();
					goto reset_RC;
					break;
				}
				// Found Header, CountPer is 24x the CK, or 8x the Period
				CountPer = (char)(CountPer >> 1);	// 4*Period
				Period = (char)((char)(CountPer+2)>>2);	// Period, rounded
				CountPer = (char)((char)(CountPer+4)>>3);	// Period/2, rounded
				Per_Max = (char)(Period+CountPer);	// Period+1/2 to check ovf 
				Per_Min = (char)(Period-CountPer);	// Period-1/2 to check udf 
				if (Per_Min < 3)
					Per_Min = 3;
				CountCycle = 32;	// it's needed 24 (Frame) 
													// + 4 (Anticode)
													// + 4 to be discarded 
				RCFrame_Input.Anticode[0] = 0;
				RC_Input_Changing = TRUE;
				StatusRx = FRAME;
      }
      break;
	
      case FRAME:
      {
				// Check Frame period timing min
				//if (CountPer < (char)(Period-1))		// error
				if (CountPer < Per_Min)		// error
				{
					//RC_Positioning();
					goto reset_RC;
					break;
				}
				else			// bit OK to be measured
				{
					//Teste de frame-------------------------/
					CountCycle--;
					/*
					_asm("ld XL,a", CountCycle>>3);              //XL is the index
					CountLow =  (char)(CountLow << 1);       // temporary, 2*
					_asm ("cp a, _CountLow", (char)(CountPer-0));
					// carry has information
					_asm ("rrc (_RCFrame_Input,X)");
					*/
					
					tmp = (char)(CountCycle>>3);    //tmp is index, nao pode ser tmp-1
					RCFrame_Input.Anticode[tmp] >>= 1;                                   //shift right
					if ((char)(CountPer-0) < (char)(CountLow*2))
					SetBit(RCFrame_Input.Anticode[tmp],7);
					
					
					
					CountLow =  (char)(CountLow << 1);
					//_asm ("cp a,_CountLow", (char)(CountPer-0));
					// carry has information
					//_asm ("rrc (_RCFrame_Input,x)");
					
					if (CountCycle==4)	// frame completed
					{
						RC_Input_Ready = TRUE;
						goto reset_RC;
						//RC_Positioning();
					}
				}
      }
      break;
			
			case OVERPERIOD:
      default:
      {
				reset_RC:
				//RC_Positioning();
				RC_Input_Changing = FALSE;
				CountCycle = 1;
				StatusRx = HEADER;
				Per_Max = NUM_HEADER_MAX;
				break;
			}
      break;
			
    }
	// **************** END Switch **************** //
    CountPer = 1;	// zeroed and incremented
    CountLow = 0;	// zeroed; compensates the 0 when an edge is detected
  }
}

PageAddrtype FindRControlInMem (PageAddrtype PageStart)
/*****************************************************************************
	FUNCTION     : FindRControlInMem ()
	DESCRIPTION  : Inside Flash or EEprom reserved area, locate the page 
		that matches with Serial number inside RCFrame_Copy; If found, 
		function returns the page number. If not, returns 0.
		Page Zero is ignored. Search start from PageStart page, going
		circularly up to PageStart-1.
	ARGUMENTS    : PageAddrtype PageStart: starting page number
	RETURN VALUE : PageAddrtype: found page number, otherwise 0.
*****************************************************************************/
{
  PageAddrtype Page;
  unsigned char register j;
	char temp;
  Page = PageStart;
  do
  {
    if (Page &&		// ignore Page zero
      LoadEE(Page) &&	// if error get next
      Mem_RC_Used ) 	// if zero (or page 0), not a valid RC
    {
			temp = (char)(Buffer.Byte[0] & 0b11000000); // get Status
      Buffer.Byte[0] &= 0b00111111;	// clear Status; pure SerialN
      //if ((@tiny)Buffer.Data.SerialN == (@tiny)SerialNumber)
      for (j = 3; j; j--)
      {
				if (BufferRam[j-1] != RCFrame_Copy.Data.Serial[j-1])
					break;	// if <>, not a equal SN
      }
      if (!j)		// if zero, passed ==   
			{
				Buffer.Byte[0] |= temp;
				return Page;
			}
    }
    Page = (PageAddrtype)((Page + 1) & (RCONTROL_PAGE_QTTY - 1));
  } while  (Page != PageStart);
  return 0;	// not found
}

PageAddrtype FindPageZeroed (PageAddrtype PageStart)
/*****************************************************************************
	FUNCTION     : FindPageZeroed ()
	DESCRIPTION  : Inside Flash or EEprom reserved area, locate the page 
		starting from PageStart input that does not have RC_Used value. 
		This search is performed in circular way. If found, function 
		returns the page number. If not, returns 0.
		Page Zero is ignored and forbiden.
	ARGUMENTS    : PageAddrtype Page - start page number
	RETURN VALUE : PageAddrtype: found free page number, otherwise 0.
*****************************************************************************/
{
  PageAddrtype Page;
  Page = PageStart;
  do
  {
    if (Page &&						// ignore Page zero
				LoadEE(Page) &&		// if error get next
				!Mem_RC_Used )		// if RC prog, get next
    {// empty
      return Page;
    }
    Page = (PageAddrtype)((Page + 1) & (RCONTROL_PAGE_QTTY - 1));
  } while (Page != PageStart);
  return (0);	// not found
}

void ProgramRemoteControl(PageAddrtype Page)
/*****************************************************************************
	FUNCTION     : ProgramRemoteControl ()
	DESCRIPTION  : Programs a Remote Control into a specific memory page
	ARGUMENTS    : None
	RETURN VALUE : None  
*****************************************************************************/
{
  signed char	j;

  // Update Page zero
  LoadEE(0);
  Buffer.Page.Addr = Page; //last entered to Page Zero
 SaveEE(0);
  // update into EE/Flash
  for (j = 2; j>=0; j--)	//Buffer.data.SerialN = SerialNumber;	
    Buffer.Byte[j] = RCFrame_Copy.Data.Serial[j];
  Mem_RC_Used = TRUE;		// indicates page used
  Mem_RC_Blocked = FALSE;		// not used indicates page blocked
	Mem_RC_Keys = RC_Keys_Copy.byte;	// which keys are pressed 
 SaveEE(Page);
}

void BlockRemoteControl(PageAddrtype Page)
/*****************************************************************************
	FUNCTION     : BlockRemoteControl ()
	DESCRIPTION  : Blocks/Releases a Remote Control of a specific 
		      memory page
	ARGUMENTS    : None
	RETURN VALUE : None  
*****************************************************************************/
{
  // update into EE/Flash
  LoadEE(Page);
  Mem_RC_Used = TRUE;		// indicates page used
  if (Mode == MODE_BLO)
    Mem_RC_Blocked = TRUE;		// indicates blocked
  else
    Mem_RC_Blocked = FALSE;		// indicates released
  SaveEE(Page);
}

void Remove_RC_Info (void)
/*****************************************************************************
	FUNCTION     : Remove_RC_Info ()
	DESCRIPTION  : This routine initiates Remote Control Routines vars. 
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  signed char j;
  for (j = 3; j >= 0; j--)	//aqui 0-3, era 0-2
  {
    RCFrame_Copy.Data.Serial[j] = 0;
    RCFrame_Copy_Previous.Data.Serial[j] = 0;
  }
  RCFrame_Address = 0;
}

void Init_RemoteControl (void)
/*****************************************************************************
	FUNCTION     : Init_RemoteControl ()
	DESCRIPTION  : This routine initiates Remote Control Routines vars. 
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  //Init_RC();	// for RC Frame capture 
  RC_Input_Ready = FALSE;
  RC_Keys.byte = 0;
  RC_Timeout = 1;
  RC_Positioning();
//  RCFrame_Copy_Previous.Data.Serial = 0;// already in Clear_Mem
  RCFrame_Address = 0;
}

void RC_Positioning (void)
/*****************************************************************************
	FUNCTION     : RC_Positioning ()
	DESCRIPTION  : This routine prepares RC vars for a new frame. 
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  RC_Input_Changing = FALSE;
  CountCycle = 1;
  StatusRx = HEADER;
  Per_Max = NUM_HEADER_MAX;
}

void EraseAllRemoteControls(void)
/*****************************************************************************
	FUNCTION     : EraseAllRemoteControls (void)
	DESCRIPTION  : Zeroes all RC pages of RCONTROL_PAGE_QTTY pages 
	ARGUMENTS    : 
	RETURN VALUE : None
	USES	       : local var, ClearRC, BufferRam IS CHANGED!!!
*****************************************************************************/
{
  sPageAddrtype Page;
  for (Page = RCONTROL_PAGE_QTTY-1; Page >= 0; Page--)
    ClearRemoteControl(Page);
}  

void ClearRemoteControl(PageAddrtype Page)
/*****************************************************************************
	FUNCTION     : ClearRemoteControl (unsigned char Page)
	DESCRIPTION  : Zeroes a page indexed by Page var
	ARGUMENTS    : Page- page index to the area to be zeroed
	RETURN VALUE : None
	USES	       : local var, SaveEE, BufferRam IS CHANGED!!!
*****************************************************************************/
{
  signed char register j;

  for(j = RCONTROL_MEM_SIZE-1; j >=0  ; j--)	// not excluded CheckSumBuffer byte
    BufferRam[j] = 0x00;
  SaveEE(Page);
}

void CheckRCConsistency (void)
/*****************************************************************************
	FUNCTION     : CheckRCConsistency (void)
	DESCRIPTION  : Zeroes all pages of RCONTROL_PAGE_QTTY pages that could 
		not be correctly read 
	ARGUMENTS    : 
	RETURN VALUE : None
	USES	     : local var, ClearRC, BufferRam IS CHANGED!!!
*****************************************************************************/
{
  sPageAddrtype Page;

  for (Page = RCONTROL_PAGE_QTTY-1; Page >= 0; Page--)
  {
    if (!LoadEE(Page)) 
      ClearRemoteControl(Page);
  }
} 

