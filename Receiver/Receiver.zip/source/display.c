/********************  (c) 2004 STMicroelectronics **************************
*Project :
*Filename  : display.c	*
*Author    : Roberto Pieruci*
***  Compiler  : Cosmic ANSI-C *
*CPU :ST7FLITE							     *
*****************************  File Contents  ********************************
*									     *
*  general setup routines for the microcontroller			     *
*									     *
******************************  Description  *********************************
*                                                                            *
*                                                                            *
*                                                                            *
**************************  Update Information  ******************************
*									     *
*  Ed. Date      Own Modification					     *
*  --- --------- ---  -----------------------------------------------------  *
*  001 Aug/16/04 RCP creation						     *
*  002 Feb/15/05 RCP improved						     *
*****************************************************************************/

/*************************  General Include Files  **************************/

#include "stm8s_conf.h"
#include "user_defs.h"		// User definitions
/****************************************************************************/

/***********************  Application Include Files  ************************/ 

#include "rcontrol_rx.h"
#define	DISPLAY
#include "display.h"
#undef DISPLAY
#include "hw_setup.h"
#include "routines.h"
/****************************************************************************/

#define INVERT_DISPLAY
#ifdef INVERT_DISPLAY
	#define TR_OFF			1
	#define TR_ON				0
	#define PORT_OFF		0xff
#else
	#define TR_OFF			0
	#define TR_ON				1
	#define PORT_OFF		0x00
#endif

void Scan_Display (void)
/*****************************************************************************
	FUNCTION     : Scan_Display ()
	DESCRIPTION  : Faz a varredura dos display dentro da interrupcao
			TimeBase1
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  //DISPLAY0_OUT = TR_OFF;		//Apaga os transistores dos leds
  GPIO_WriteLow(GPIOA,GPIO_PIN_5);
	//DISPLAY1_OUT = TR_OFF; 
  GPIO_WriteLow(GPIOA,GPIO_PIN_6);
	//DISPLAY2_OUT = TR_OFF; 
  GPIO_WriteLow(GPIOB,GPIO_PIN_1);
	GPIO_WriteLow(GPIOD,GPIO_PIN_ALL);
	//PADR = PORT_OFF;					//Apaga o port A
  Display_Pointer--;
  if (Display_Pointer == 255)
  {
    Display_Pointer = 2;
  }
  PD_ODR = (char) (Display_Output[Display_Pointer] ^ PORT_OFF); 
  switch (Display_Pointer)
  {
    case 0:
    {
      //DISPLAY0_OUT = TR_ON;
			GPIO_WriteHigh(GPIOA,GPIO_PIN_5);
    }
    break;
    case 1:
    {
      //DISPLAY1_OUT = TR_ON;
			GPIO_WriteHigh(GPIOA,GPIO_PIN_6);
    }
    break;
    case 2:
    {
      //DISPLAY2_OUT = TR_ON;
			GPIO_WriteHigh(GPIOB,GPIO_PIN_1);
    }
    break;
    default:
    {
    }
    break;
  }
}

void Update_Display (void)
/*****************************************************************************
	FUNCTION     : Update_Display ()
	DESCRIPTION  : Faz o Update dos display  
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  signed char register i;
  unsigned char temp;

// Blink check
  if (ValBit(Display_Blink,BLINK_ON))
  {
    if (!--Display_Blink_Count)
    {
      Display_Blink_Count = TIME_BLINK;
      CmpBit(Display_Blink,BLINK_STATUS);
    }
    if (ValBit(Display_Blink,BLINK_STATUS))
      temp = 0;
    else
      temp = Display_Blink;  
  }
  else
  {
    ClrBit(Display_Blink,BLINK_STATUS);
    Display_Blink_Count = TIME_BLINK;
    temp = 0;
  }
  // Blink update
  for (i = 0; i <= 2; i++)
  {
    temp >>=1;
    if (carry())
      Display_Output[i] = 0;
    else
      Display_Output[i] = Display_Buffer[i];
  }
  for (i = 0; i <= 2; i++)
  {
    temp >>=1;
    if (carry())
      Display_Output[i] &= (char)~DP; 
    else
      if (Display_DP[i])
	Display_Output[i] |= DP;
  }
}

void Hexa_to_Decimal(int Hexa)
/*****************************************************************************
	FUNCTION     : Hexa_to_Decimal (int Hexa)
	DESCRIPTION  : Converte a vari�vel de entrada em tres chars decimais  
	ARGUMENTS    : Hexa
	RETURN VALUE : Decimal [3], DMS =2
*****************************************************************************/
{
  int rasc;
  //Decimal[0] = (char) (Hexa % 10);
  //Decimal[1] = (char) (((char) (Hexa / 10)) % 10);
  //Decimal[2] = (char) (((char) (Hexa / 10)) / 10);
  //_asm ("ld _Decimal,y", rasc = (int)(Hexa / 10) );	// y contem o resto
  //_asm ("ld _Decimal+1,y", Decimal[2] = (char) (rasc / 10) );
}

