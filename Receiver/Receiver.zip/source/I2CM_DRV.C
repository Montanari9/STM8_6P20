/********************  (c) 2005 STMicroelectronics  **************************
*  Project   : any							     *
*  Filename  : i2cm_drv.c						     *
*  Author    : Micro Controller Division Application Team		     *
*                                                                            *
*  Compiler  : Cosmic ANSI-C						     *
*  CPU       : ST7FLITE							     *
*****************************  File Contents  ********************************
*									     *
*  general setup routines for ST7 I2C single master			     *
*									     *
******************************  Description  *********************************
*                                                                            *
*    ST7 I2C single master T/R peripheral software driver.                   *
*                                                                            *
**************************  Update Information  ******************************
*                                        				     *
*  Ed. Date      Own Modification					     *
*  --- --------- ---  -----------------------------------------------------  *
*  001 Jun/12/03 MCU creation						     *
*  002 Nov/15/05 RCP improved						     *
*****************************************************************************/

/*************************  General Include Files  **************************/

#include "user_defs.h"		// User definitions
#include "io7flite_select.h"	// CPU Selection
#include "cpu_inlines.h"	// ST7 specific definitions
/****************************************************************************/

/***********************  Application Include Files  ************************/     

#include "rcontrol_rx.h"
#include "flash_eeprom.h"
#include "routines.h"
#define	I2CM_DRV
#include "i2cm_drv.h"
#undef I2CM_DRV

/****************************************************************************/

#if FLASH_EE == 2	// I2C External Eeprom
/*-----------------------------------------------------------------------------
ROUTINE NAME : delay
INPUT/OUTPUT : unsigned char time
DESCRIPTION  : delay, cycle time = 125ns @8MHz
delay: 2+6 + (3+3)*time + 6 = 14 + 6*time  
ex: Time = 1 -> delay = 20cy, -> 2.50us
ex: Time = 2 -> delay = 26cy, -> 3.25us
ex: Time = 3 -> delay = 32cy, -> 4.00us
ex: Time = 4 -> delay = 38cy, -> 4.75us
ex: Time = 255 -> delay = 1544cy, -> 193.00us
COMMENTS     : Contains inline assembler instructions in C like mode !
-----------------------------------------------------------------------------*/ 
void delay (unsigned char Time)		//2+6 cy
{
  _asm ("i2c_again: DEC A");		//3 cy
  _asm (" JRNE i2c_again");		//3 cy
}					//6 cy
       
/*-----------------------------------------------------------------------------
ROUTINE NAME : I2C_WAIT_10ms
INPUT/OUTPUT : delay(255)/None
DESCRIPTION  : Generate ~10ms, cycle time = 125ns @8MHz
Time = 255 -> delay = 1544cy, -> 193.00us
This repeats 52 times, 52*193u =~10ms
COMMENTS     : 
-----------------------------------------------------------------------------*/ 
void I2C_WAIT_5ms (void) /* Wait for ~5ms.*/
{
  char i;
  for (i=55; i; i--)
  {
    delay(255);	//26*193u =~5ms
  } 
}

/*-----------------------------------------------------------------------------
ROUTINE NAME : I2Cm_Start
INPUT/OUTPUT : None.
DESCRIPTION  : Generates I2C-Bus Start Condition.
COMMENTS     :
      -------'-----'-----'-----'
SCL          |                 |
      -------'                 '-----'------'-
      -'-----------'-----'	     
SDA    |           |     | 
      -'           '-----'-----------'------'-
-----------------------------------------------------------------------------*/ 
void I2Cm_Start (void)
{
  // Introduction: signals preparation
  // Configure SDA as floating input to have a high state 
  ClrBit(I2C_Port_Direction,SDA);	// 5cy, 625ns  
  // Configure SCL as output high to have a high state 
  SetBit(I2C_Port_Data,SCL);   		// 5cy, 625ns
  // delay(1);	// not needed
  // Start: signals perform
  // Configure SDA as output open drain to have a low state
  SetBit(I2C_Port_Direction,SDA);   	// 5cy, 625ns 
  ClrBit(I2C_Port_Data,SDA);   		// 5cy, 625ns
  // delay(4);	// not needed
  // Configure SCL as output low to have a low state
  ClrBit(I2C_Port_Data,SCL);   		// 5cy, 625ns
  // delay(1); 	// Delay to wait after a START, not needed
}					// 6cy, 750ns 

/*-----------------------------------------------------------------------------
ROUTINE NAME : I2Cm_Stop
INPUT/OUTPUT : None.
DESCRIPTION  : Generates I2C-Bus Stop Condition.
COMMENTS     :
      -------'-----'     '-----'-----'------'-
SCL                |     |      
      -------'----- -----'     
      -'-----'                 '-----'------'-     
SDA    |     |                 | 
      -'-----'-----'-----'-----'
-----------------------------------------------------------------------------*/
void I2Cm_Stop (void)    
{
  // Introduction: signals preparation
  // Configure SDA as output open drain to have a low state
  SetBit(I2C_Port_Direction,SDA);  	// 5cy, 625ns   
  ClrBit(I2C_Port_Data,SDA);   		// 5cy, 625ns
  // Configure SCL as output low drain to have a low state
  ClrBit(I2C_Port_Data,SCL);   		// 5cy, 625ns
  // Stop: signals perform
  // Configure SCL as output high to have a high state
  SetBit(I2C_Port_Data,SCL);   		// 5cy, 625ns 
  // delay(1);	// not needed
  // Configure SDA as floating input to have a high state  
  ClrBit(I2C_Port_Direction,SDA);  	// 5cy, 625ns 
  // delay(1); 	// Delay to wait after a STOP, not needed 
}					// 6cy, 750ns 

/*-----------------------------------------------------------------------------
ROUTINE NAME : I2Cm_Tx
INPUT/OUTPUT : I2C_Addr, BufferEE / AF error Flag.
DESCRIPTION  : Transmit data buffer. "Page Write Mode" and "Sequential Randon Read"
	       This routine performs I2C_Start before transmitting all bytes.
	       At the end, SCL will be always Low.
COMMENTS     : Most significant bytes first. Sent bytes are organized from 0 to N+1:
USES         : I2C_Addr[] 0: Dev_Sel; 1: Address byte; for Write and Read modes
	       BufferEE[] 0: Data0; ... N-1: Data N-1 for Write mode
-----------------------------------------------------------------------------*/ 
void I2Cm_Tx (void)
{
  unsigned char j;
  I2Cm_Start();		// SDA is 0; SCL is 0
  // Configure SDA as an output open-drain to send data
  // SetBit(I2C_Port_Direction,SDA);	// already done in I2Cm_Start
  for (j = 0; j < (I2C_N+2); j++)	// for every byte of buffer 
  { // 2 addresses and I2C_N data to send: from X=0 upto X=5
    switch (j)
    {
      case 0:
      case 1:
      {
	I2C_DR=I2C_Addr[j];
      }
      break;
      case 2:
      {	// already sent Dev_Sel and Byte_Address,
	if (ValBit(I2C_SR,READ))	// in READ Mode
	{
	  I2Cm_Start();		// Start condition to second time
	  j = (char)(I2C_N+2);		// no more bytes to be Tx
	  I2C_DR=(char)(I2C_Addr[0]|1);	// again Dev_Sel, R/W=1
	}
	else goto defwrite;
      }
      break;
      default:
      {	defwrite:
	I2C_DR=BufferEE[j-2];
      }
      break;
    }
    I2Cm_TxByte();	// Sending of data bit per bit, MSB first; SDA ends FloatInput       
    I2C_Wait_Ack();	// Wait ACK from the slave; SDA ends FloatInput
    if(ValBit(I2C_SR,AF))	// Ack Failed
      return;			// abort due to AF
  }
}

/*-----------------------------------------------------------------------------
ROUTINE NAME : I2Cm_Rx
INPUT/OUTPUT : I2C_Addr, BufferEE / AF error Flag.
DESCRIPTION  : Receive in data buffer via I2C.
               This routine assumes after I2Cm_Tx sending Address
	       At the end, SCL will be always Low.
COMMENTS     : Most significant bytes first.
USES         : BufferEE[] 0: Data0; ... N-1: Data N-1 for Read mode
-----------------------------------------------------------------------------*/ 
void I2Cm_Rx (void)
{
  unsigned char j;
  for (j = 0; j < I2C_N; j++)
  {
    I2Cm_RxByte(); 	// Reading data bit per bit, MSB first; SDA ends Out any
    BufferEE[j]=I2C_DR;	// Store read data into BufferEE 
    if (j == I2C_N-1)
      I2C_nAck();  	// Non acknowledge, final byte
    else
      I2C_Ack();	// To acknowledge read data                 
  }
}

/*-----------------------------------------------------------------------------
ROUTINE NAME : I2Cm_TxByte
INPUT/OUTPUT : I2C_DR(MSB first) / None.
DESCRIPTION  : Transmits a data byte I2C_DR
COMMENTS     : SCL starts Low, ends Low; SDA starts Any, ends Float Input
-----------------------------------------------------------------------------*/ 
void I2Cm_TxByte (void)
{
  unsigned char register count;
  SetBit(I2C_Port_Direction,SDA); 	// Output any 5cy, 625ns  
  for (count = 8; count; count--)	// bit count
  {
    I2C_DR <<= 1;	// Send data bit per bit
    if (carry())
      SetBit(I2C_Port_Data,SDA);	// Send a one 
    else
      ClrBit(I2C_Port_Data,SDA);	// Send a zero  5cy, 625ns
    SetBit(I2C_Port_Data,SCL);          // High state on SCL 5cy, 625ns 
    //delay(1); 			// not needed
    //Nop();				// 2cy, 250ns
    ClrBit(I2C_Port_Data,SCL);          // Low state on SCL 5cy, 625ns 
  }
  ClrBit(I2C_Port_Direction,SDA);	// SDA ends Floating input
}    

/*-----------------------------------------------------------------------------
ROUTINE NAME : I2Cm_RxByte
INPUT/OUTPUT : None / I2C_DR(MSB first)
DESCRIPTION  : Receive a data byte.
COMMENTS     : SCL starts Low, ends Low; SDA starts Any, ends Output any
-----------------------------------------------------------------------------*/ 
void I2Cm_RxByte (void)
{
  unsigned char count;
  ClrBit(I2C_Port_Direction,SDA); 	// Floating Input 5cy, 625ns                
  for (count = 8; count; count--)	// bit count
  {
    I2C_DR <<= 1;         		// Shift I2C_DR to receive carry
    SetBit(I2C_Port_Data,SCL);          // High state on SCL 5cy, 625ns
    if(ValBit(I2C_Port_Data,SDA))
      I2C_DR |= 1; 			// Data bit into I2C_DR
    ClrBit(I2C_Port_Data,SCL);          // SCL at a low level 5cy, 625ns 
    //delay(1);	// not needed
  }
  SetBit(I2C_Port_Direction,SDA);	// SDA ends Output any
}
       
/*-----------------------------------------------------------------------------
ROUTINE NAME : I2C_Wait_Ack
INPUT/OUTPUT : None/AF of I2C_SR
DESCRIPTION  : Acknowledge received? The slave has to pull SDA low
COMMENTS     : SCL starts Low, ends Low; SCA starts and ends Float Input
-----------------------------------------------------------------------------*/ 
void I2C_Wait_Ack (void)
{       
  ClrBit(I2C_SR,AF);
  SetBit(I2C_Port_Data,SCL); 		// High state on SCL 5cy, 625ns 
  //delay(1);	//not needed
  if (ValBit(I2C_Port_Data,SDA))	// Test of SDA level, if high -> nAck
     { 
          SetBit(I2C_SR,AF);
     }
  ClrBit(I2C_Port_Data,SCL);		// Low state on SCL 5cy, 625ns 
  // SDA ends as floating input         
} 

/*-----------------------------------------------------------------------------
ROUTINE NAME : I2C_Ack
INPUT/OUTPUT : None.
DESCRIPTION  : Send Ack to the slave.
COMMENTS     : SCL starts Low, ends Low; SCA starts and ends Ouput Low
-----------------------------------------------------------------------------*/ 
void I2C_Ack (void)
{
  ClrBit(I2C_Port_Data,SDA);	// Send a zero  5cy, 625ns
  SetBit(I2C_Port_Data,SCL);	// High state on SCL 5cy, 625ns 
  //delay(1); 			// not needed
  Nop();			// 2cy, 250ns
  ClrBit(I2C_Port_Data,SCL);	// Low state on SCL 5cy, 625ns 
  // SDA ends as Output Low         
}        

/*-----------------------------------------------------------------------------
ROUTINE NAME : I2C_nAck
INPUT/OUTPUT : None.
DESCRIPTION  : Non acknoledge sent to the slave.
COMMENTS     : SCL starts Low, ends Low; SCA starts and ends Ouput ODrain
-----------------------------------------------------------------------------*/ 
void I2C_nAck (void)
{
  SetBit(I2C_Port_Data,SDA);	// Send a One  5cy, 625ns
  SetBit(I2C_Port_Data,SCL);	// High state on SCL 5cy, 625ns 
  //delay(1); 			// not needed
  Nop();			// 2cy, 250ns
  ClrBit(I2C_Port_Data,SCL);	// Low state on SCL 5cy, 625ns 
  // SDA ends as Output High         
} 

//#if FLASH_EE == 2	// True I2C EEPROM used
void WriteI2C (void)
/*****************************************************************************
	FUNCTION     : WriteI2C ()
	DESCRIPTION  : Writes to an ammount of bytes sized BLOCK_EE_SIZE 
		inside a  Block of I2C EEPROM, addressed at *PointerFlash,  
		from the same ammount of Ram at BufferEE address. No need
		erasing block.
	ARGUMENTS    : None
	RETURN VALUE : None
	USES	     : *PointerFlash: address in a page to be written into;
		       I2C_Addr: addres to write into; BufferEE: data
*****************************************************************************/
{
  unsigned char register j;

  // Prepare I2C_send
  I2C_Addr[0] = (char)((((int)((char @near *)PointerFlash)) >> 8) << 1
		    | 0b10100000);	// Dev_Sel
  I2C_Addr[1] = (char)(((int)((char @near *)PointerFlash)) & 0xff);	//Addr

  ClrBit(I2C_SR,READ);		// Write Mode	
  for (j = 4; j; j--)		// 4 attempts
  {
    I2Cm_Tx();		// Transmit data bytes to the slave
    if (!ValBit(I2C_SR,AF))
    {
      break;
    }
  }
  I2Cm_Stop();
  I2C_WAIT_5ms();
} 
//#endif

//#if FLASH_EE == 2	// True I2C EEPROM used
void ReadI2C (void)
/*****************************************************************************
	FUNCTION     : ReadI2C ()
	DESCRIPTION  : Read from an ammount of bytes sized BLOCK_EE_SIZE 
		inside a  Block of I2C EEPROM, addressed at *PointerFlash,  
		to the same ammount of Ram at BufferEE address. 
	ARGUMENTS    : None
	RETURN VALUE : None
	USES	     : *PointerFlash: address in a page to be read from;
		       I2C_Addr: addres to read from; BufferEE: data
*****************************************************************************/
{
  unsigned char register j;

  // Prepare I2C_send
  I2C_Addr[0] = (char)((((int)((char @near *)PointerFlash)) >> 8) << 1
		    | 0b10100000);	// Dev_Sel
  I2C_Addr[1] = (char)(((int)((char @near *)PointerFlash)) & 0xff);	//Addr
  
  SetBit(I2C_SR,READ);		// Read Mode	
  for (j = 4; j; j--)		// 4 attempts
  {
    I2Cm_Tx();		// Transmit data bytes to the slave
    if (!ValBit(I2C_SR,AF))
    {
      break;
    }
  }
  I2Cm_Rx();
  I2Cm_Stop();
} 
//#endif

/*-----------------------------------------------------------------------------
ROUTINE NAME : I2Cm_Init
INPUT/OUTPUT : None.
DESCRIPTION  : I2C peripheral initialisation routine.
COMMENTS     : Contains inline assembler instructions in C like mode !
-----------------------------------------------------------------------------*/ 
void I2Cm_Init (void)
{
  I2C_SR=0;
  I2C_DR=0;
  I2Cm_Universal_Reset();
} 

/*-----------------------------------------------------------------------------
ROUTINE NAME : I2Cm_Universal_Reset
INPUT/OUTPUT : None.
DESCRIPTION  : I2C peripheral Universal Reset routine.
COMMENTS     : Contains inline assembler instructions in C like mode !
-----------------------------------------------------------------------------*/ 
void I2Cm_Universal_Reset (void)
{
  unsigned char j;
  //ClrBit(I2C_Port_Data,SCL);		// Low state on SCL      5cy, 625ns 
  //ClrBit(I2C_Port_Direction,SDA); 	// Floating Input on SDA 5cy, 625ns 
  for (j=9; j; j--)
  {
    ClrBit(I2C_Port_Data,SCL);		// Low state on SCL      5cy, 625ns 
    ClrBit(I2C_Port_Direction,SDA); 	// Floating Input on SDA 5cy, 625ns
    Nop();
    Nop();
    if (ValBit(I2C_Port_Data,SDA))	// if High then nAck
    {
      I2Cm_Start();
      I2Cm_Stop();
      break;
    }
  SetBit(I2C_Port_Data,SCL);		// High state on SCL     5cy, 625ns 
  SetBit(I2C_Port_Direction,SDA); 	// Output on SDA         5cy, 625ns 
  ClrBit(I2C_Port_Data,SDA);	 	// Low state on SDA      5cy, 625ns 
  }
} 

#endif
/******************* (c) 2005  STMicroelectronics ************ END OF FILE ***/
