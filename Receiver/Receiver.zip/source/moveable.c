/********************  (c) 2004 STMicroelectronics  **************************
*  Project   : 								     *
*  Filename  : moveable.c						     *
*  Author    : Roberto Pieruci						     *
*                                                                            *
*  Compiler  : Cosmic ANSI-C						     *
*  CPU       : ST7							     *
*****************************  File Contents  ********************************
*									     *
*  IAP Flash Routines in the Moveable segment to IAP program IAP	     *
*									     *
******************************  Description  *********************************
*                                                                            *
*                                                                            *
*                                                                            *
**************************  Update Information  ******************************
*									     *
*  Ed. Date      Own Modification					     *
*  --- --------- ---  -----------------------------------------------------  *
*  001 Aug/16/04 RCP creation						     *
*  002 Feb/15/05 RCP improved						     *
*****************************************************************************/

/*************************  General Include Files  **************************/

#include "stm8s_conf.h"
#include "user_defs.h"		// User definitions
#include "timingsLit_setup.h"	// System Clock Setup
/****************************************************************************/

/***********************  Application Include Files  ************************/     

#include "hw_setup.h"
#include "rcontrol_rx.h"
#include "flash_eeprom.h"
#define MOVEABLE
#include "moveable.h"
#undef MOVEABLE
/****************************************************************************/

#if FLASH_EE == 1	// FLASH as EEprom
void ProgramFlashBlock (unsigned char @near *FlashAddr,	// to
			unsigned char @tiny *RamAddr)	// from
/*****************************************************************************
	FUNCTION     : ProgramFlashBlock ()
	DESCRIPTION  : Controls the ICP FLASH flags, and transfer a fixed
		amount of RAM to the Flash area, executing the Flash 
		programming cycle.
		- Code MUST be running into RAM area; using Moveable segment.
		- After setting PGM bit, routine will be held about 5ms. this
		is the Programming time.
	*** This is a 32-byte PAGING access routine: 
	integer(FlashAdd/32) MUST be = integer((FlashAddr+RamSize)/32) ***
		 
	ARGUMENTS    : unsigned char @near *FlashAddr: Pointer to the Flash
	RETURN VALUE : None
*****************************************************************************/
{
unsigned char register j;
LAT = 1; 	// starts programming phase, open Flash 
// copy bytes to be programmed at Flash area
for (j=0; j < BLOCK_EE_SIZE; j++)
	{
	*(FlashAddr + j) = *(RamAddr + j);		
	}
	   
PGM = 1; 	// actives the programming Hardware
while (LAT)	// waits programming cycle finish
	{
	// Put here every code that must be running while Flash is programmed.
	// It will be passed to RAM area and be executed from RAM. Example:
	//	- Timebase  interruption for Scan using the TBF1 pooling;
	//	- Reduced User Interface Scan routine for Leds drivers

//	if (TB1F)
		{
		//Set_WatchDog();
		{
		// Your Code
		}
		}
	}
}
#endif

