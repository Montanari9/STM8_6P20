/********************  (c) 2004 STMicroelectronics  **************************
*  Project   : Xflash_RC_V0						     *
*  Filename  : hw_setup.c						     *
*  Author    : Roberto Pieruci						     *
*                                                                            *
*  Compiler  : Cosmic ANSI-C						     *
*  CPU       : ST7FLITE							     *
*****************************  File Contents  ********************************
*									     *
*  general setup routines for the microcontroller			     *
*									     *
******************************  Description  *********************************
*                                                                            *
*                                                                            *
*                                                                            *
**************************  Update Information  ******************************
*									     *
*  Ed. Date      Own Modification					     *
*  --- --------- ---  -----------------------------------------------------  *
*  001 Aug/16/04 RCP creation						     *
*  002 Feb/15/05 RCP improved						     *
*****************************************************************************/

/*************************  General Include Files  **************************/
#include "stm8s_conf.h"
/****************************************************************************/

/***********************  Application Include Files  ************************/     

#define	HW_SETUP
#include "hw_setup.h"
#undef HW_SETUP
#include "routines.h"
/****************************************************************************/

void Set_Ports(void)
/*****************************************************************************
	FUNCTION     : Set_Ports ()
	DESCRIPTION  : ST7FLITE1x/2x/3x IO setup
	ARGUMENTS    : None
	RETURN VALUE : None
	
	PORT A:    Function(config), 2nd func	OutAct	Initializat Interr			
	76543210
	||||||||
	|||||||0-- DISPLAY 1 (A)		1	OUT PP 0	N
	||||||1--- DISPLAY 2 (B)		1	OUT PP 0	N
	|||||2---- DISPLAY 3 (C)		1	OUT PP 0	N
	||||3----- DISPLAY 4 (D)		1	OUT PP 0	N
	|||4------ DISPLAY 5 (E)		1	OUT PP 0	N
	||5------- DISPLAY 6 (F)		1	OUT PP 0	N
	|6-------- DISPLAY 7 (G)		1	OUT PP 0	N
	7--------- DISPLAY 8 (H)		1	OUT PP 0	N 
	 
	PORT B:    Function(config)		OutAct	Initializat	Interr		
	76543210
	||||||||
	|||||||0-- SCL Single Master (OUT PP)	0	OUT PP 0	N
	||||||1--- SDA (IN  HZ)	        	0	IN  HZ 0	N
	|||||2---- RL1 (OUT PP)			0	OUT PP 0	N
	||||3----- SWITCH1(IN PU)		0	IN  PU 0	N
	|||4------ SWITCH2(IN PU)		0	IN  PU 0	N
	||5------- DP1(OUT PP)			0	OUT PP 0 	N
	|6-------- DP0(OUT PP)			0	OUT PP 0 	N
	7--------- NA(DEFAULT)			-	IN  HZ 1	N
	 
	PORT C:    Function(config)		OutAct	Initializat	Interr		
	76543210
	||||||||
	|||||||0-- RXPIN(IN HZ)			1	IN HZ  0	N
	||||||1--- DP2(OUT OD)			0	OUT OD 0 	N
	765432---- NA(DEFAULT)			-	IN  HZ 0	N
	
*****************************************************************************/
{
  GPIO_Init(GPIOD,GPIO_PIN_ALL,GPIO_MODE_OUT_PP_LOW_FAST);
	GPIO_Init(GPIOC,GPIO_PIN_2,GPIO_MODE_OUT_PP_LOW_FAST);
	//PADDR = 0b11111111; 	
  //PAOR =  0b11111111;
  //PADR =  0b00000000;
  GPIO_Init(GPIOA,(GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6),GPIO_MODE_OUT_PP_LOW_FAST);  
  GPIO_Init(GPIOG,(GPIO_PIN_0|GPIO_PIN_1),GPIO_MODE_IN_PU_NO_IT);
  //PBDDR = 0b01100101; 	
  //PBOR =  0b01111101;
  //PBDR =  0b10000000;
  GPIO_Init(GPIOE,GPIO_PIN_3,GPIO_MODE_IN_FL_NO_IT);  
  GPIO_Init(GPIOB,GPIO_PIN_1,GPIO_MODE_OUT_PP_LOW_FAST);	
	GPIO_Init(GPIOE,GPIO_PIN_2,GPIO_MODE_OUT_PP_LOW_FAST);	
  //PCDDR = 0b00000010; 	
  //PCDR =  0b00000000;

 // EISR =  0b10110000;		// External Interrupt Selection Reg
			        // 	ei3 disable (PB2 = OUT)
			        // 	ei2 disable (PB6 = OUT)
			        // 	ei1 disable (PA4 = OUT)
			        // 	ei0 disable (PA0 = OUT)
 // EICR =  0b00000000;		// External Interrupt Ctrl Reg: doesn't matter
			      // Here, falling edge only
}	

void Set_Timebase1(void)
/*****************************************************************************
	FUNCTION     : Set_Timebase1 ()
	DESCRIPTION  : Lite Timer initialization: configures Lite Timer to 
		generate a Timebase1 according to the PER_TB1 definition. 
		- PER_TB1:    Lite Timer Timebase1 Period in nanosecs
		Interruption is required according to LTTB definition.
	ARGUMENTS    : None
	RETURN VALUE : None

	Lite Timer Control and Status Register 
    	LTCSR1/LTCSR
	76543210
	||||||||
	|||||210-- Reserved	should be	0
	||||3----- TB1F		Int Flag	0 = reset pending
	|||4------ TB1IE 	Int Enable	1 = Enable
	||5------- TB		Timebase	0 = 1ms@FCPU=8MHz; from LTTB
	|6-------- ICF		not used	0
	7--------- ICIE		not used	0 
*****************************************************************************/
{
  // For Lite1x/2x/3x
  //LTCSR1 = (0b00010000 | (LTTB<<5));	// TB1IE = 1; TB according to LTTB
	TIM4_TimeBaseInit(TIM4_PRESCALER_128,T_PWM_TIM4);
	//Enable TIM4 interrupt
  TIM4_ITConfig(TIM4_IT_UPDATE, ENABLE);
  //Enable TIM4 
  TIM4_Cmd(ENABLE);
}

// For Lite1x/2x/3x
void Set_Autoreload_Timer(void)
/*****************************************************************************
	FUNCTION     : Set_Autoreload_Timer ()
	DESCRIPTION  : AutoReload Timer initialization: configures Timer to 
		generate Overflow according to the PER_ATR_OVF definition. 
		- PER_ATR_OVF: AutoReload Timer Period in nanosecs
		- ATR_VAL: AutoReload Timer ATR value for ATR reg
		- PWM0, 1, 2, 3 OFF
		- Interruption is required every Overflow of CNTR reg.
	ARGUMENTS    : None
	RETURN VALUE : None

	AT Control and Status Register 
    	ATCSR
	76543210
	||||||||
	|||||||0-- CMPIE	not used	0
	||||||1--- OVFIE	OV int enable	1 = enable
	|||||2---- OVF		OV int flag	0 = read reset pending
	||||3----- CK0	\
	|||4------ CK1	/ 	Clock selection	According ATCLK selection
	||5------- ICIE		not used	0
	|6-------- ICF		not used	0
	7--------- Reserved	should be	0

	PWM Output Control Register 
    	PWMCR
	76543210
	||||||||
	|||||||0-- OE0		not used	0
	||||||1--- Reserved	should be	0
	|||||2---- OE1		not used 	0
	||||3----- Reserved	should be	0
	|||4------ OE2		not used	0
	||5------- Reserved	should be	0
	|6-------- OE3		not used	0
	7--------- Reserved	should be	0 

	PWMx Control and Status Register 
    	PWMxCSR
	76543210
	||||||||
	|||||||0-- CMPFx	not used	0
	||||||1--- OPx		not inverted	0
	765432---- Reserved	should be	0

	BREAK Control Register 
    	BREAKCR
	76543210
	||||||||
	|||||||0-- PWM0		break pattern	0
	||||||1--- PWM1		break pattern	0
	|||||2---- PWM2		break pattern	0 
	||||3----- PWM3		not used	0
	|||4------ BPEN		break enabled	0 Not compatible with Debuger
	||5------- BA		not active	0
	|6-------- BREDGE	should be	0 (Reserved if ST7FLITE3)
	7--------- BRSEL	should be	0 (Reserved if ST7FLITE3)

	BREAKEN Break Enable Register 
    	PWMxCSR
	76543210
	||||||||
	|||||||0-- BREN1	not used	0 (Reserved if ST7FLITE3)
	||||||1--- BREN2	not used	0 (Reserved if ST7FLITE3)
	765432---- Reserved	should be	0

	AT Control and Status Register 2 (Only for ST7FLITE3x family) 
    	ATCSR2
	76543210
	||||||||
	|||||||0-- TRAN1	transfer1 OK	1
	||||||1--- TRAN2	transfer2 OK	1
	|||||2---- ENCNTR2	counter2	0 = counter 2 disable
	||||3----- OVF2		OV int flag	0 = read reset pending
	|||4------ OVFIE2	OV2 int enable	0 = disabled
	||5------- ICS		not active	0
	|6-------- FORCE1	should be	0 (Reserved if ST7FLITE3) 
	7--------- FORCE2	should be	0 (Reserved if ST7FLITE3) 

*****************************************************************************/
{
  TIM1_TimeBaseInit(0, TIM1_COUNTERMODE_UP,T_PWM_TIM1,0);
	//TIM1 Interrupt enable
  TIM1_ITConfig(TIM1_IT_UPDATE, ENABLE);
	//TIM1 counter enable 
  TIM1_Cmd(ENABLE);
	/*
	ATR1 = ATR_VAL; 			// Auto Reload Register in PWM mode 
  //	ATR2 = ATR_VAL;			// Auto Reload Register in PWM mode, with
					// Dual timer Mode

  ATCSR = (0b00000010 | (ATCLK<<3)); 	// Timer Control/Status Register
  PWMCR = 0b00000000; 			// PWM Outputs OFF
  PWM0CSR &= 0;				// PWM 0 not inverted, clear Pend
  PWM1CSR &= 0;				// PWM 1 not inverted, clear Pend
  PWM2CSR &= 0;				// PWM 2 not inverted, clear Pend
  PWM3CSR &= 0;				// PWM 3 not inverted, clear Pend
  BREAKCR = 0x00;			// Patterns 0, break pin disabled
  ATCSR2 = 0b00000011;			// Allows transfer of DCR after Ovf
  //	ATCSR2 = 0b00000111;		// Allows transfer of DCR after Ovf, with
					// Dual timer Mode*/
}


