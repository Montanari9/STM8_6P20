/********************  (c) 2004 STMicroelectronics  **************************
*  Project   : Xflash_RC_V0						     *
*  Filename  : routines.c						     *
*  Author    : Roberto Pieruci						     *
*                                                                            *
*  Compiler  : Cosmic ANSI-C						     *
*  CPU       : ST7FLITE1Bx						     *
*****************************  File Contents  ********************************
*									     *
*  general routines for the microcontroller      			     *
*									     *
******************************  Description  *********************************
*                                                                            *
*                                                                            *
*                                                                            *
**************************  Update Information  ******************************
*									     *
*  Ed. Date      Own Modification					     *
*  --- --------- ---  -----------------------------------------------------  *
*  001 Aug/16/04 RCP creation						     *
*  002 Feb/15/05 RCP improved						     *
*  003 Jan/09/07 to avoid previous keys to be saved in PEC

*****************************************************************************/

/*************************  General Include Files  **************************/
#include "stm8s_conf.h"
#include "user_defs.h"		// User definitions
#include "timingsLit_setup.h"	// System Clock Setup
/****************************************************************************/

/***********************  Application Include Files  ************************/     

#include "hw_setup.h"
#define	ROUTINES
#include "routines.h"
#undef ROUTINES
#include "interrupt.h"
#include "rcontrol_rx.h"
#include "flash_eeprom.h"
#include "display.h"

/****************************************************************************/

void Reset_Mode (void)
/*****************************************************************************
	FUNCTION     : Reset_Mode ()
	DESCRIPTION  :  
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  Mode_Time = TIME_10S;
  Error_Time = 0;
  Selection = 0;
  RC_Address = 0;
  Blink_Nothing();
  Put_Message_on_Display(Mode);
}

void Set_Error (void)
/*****************************************************************************
	FUNCTION     : Set_Error ()
	DESCRIPTION  :  
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  Blink_Digits();
  Error_Time = TIME_3S;
  Mode_Time = TIME_10S;
  Selection = 4;	// error
}

void Process_Mode (void)
/*****************************************************************************
	FUNCTION     : Process_Mode ()
	DESCRIPTION  :  
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  // Check Time Overflow
  if (Error_Time)
    Error_Time--;
  if (Mode_Time && !--Mode_Time)	// overflow de tempo do Modo
  {
    Mode = MODE_INITIAL;
    Reset_Mode();
    Mode_Time = 0;
  }
  
  // For Any Mode, if Key_Mode pressed, abort current and change to next mode
  if (Key_Mode.Edge)	// key pressed
  {
    if (Selection == 0)	// Main Menu, move on selection; otherwise restart same mode
    {
      if (++Mode > MODE_LOC)		
				Mode = MODE_INITIAL;
    }
    Reset_Mode();
    return;
  }
  
  // Get specifics for each Mode
  switch (Mode)
  {

    case MODE_INITIAL:
    {
      if (RC_Frame.Edge)	//CR pressed
      {
				if (RCFrame_Address)	// into the memory
				{
					if ((Mem_RC_Key0 && RC_Key0) || (Mem_RC_Key1 && RC_Key1))	//rcp
					{
						RC_Address = RCFrame_Address;	// from frame evaluation
						Put_Address_on_Display (RC_Address);
						Mode_Time = TIME_10S;	// enable clearing display
						if (!Display_DP[2])	// from Put_Address routine, not blocked
							Set_Relay();
					}
				}
				else
				{
					Put_Message_on_Display (MSG_DASH);
					Mode_Time = TIME_10S;	// enable clearing display
				}
      }
    }
    break;
    
    case MODE_PEC:	//PEC - Programa��o endere��vel 
    {
      Check_Selection_and_Digit();
      Treat_Display_Page_Address();
      
      if (Selection == 5)	// check consistency
      {
				// if CR already in Memory
				if (RCFrame_Address)	// yes
				{
					if (RCFrame_Address == RC_Address)
					{	// same position, not an error
						RC_Keys_Copy.byte |= (char)(Mem_RC_Keys & 0xc0); // include keys
						goto progok;
					}
					else
					{	// different position
						RC_Address = RCFrame_Address;	// from frame evaluation
						Put_Address_on_Display (RC_Address);
						Set_Error();
						break;
					}
				}
				// if Mem already used
				if (Display_DP[1])	// from Put_Address routine
				{
					Put_Message_on_Display(ERROR_1);
					Set_Error();
					break;
				}
				// OK to program
				progok:
				ProgramRemoteControl(RC_Address);
				Remove_RC_Info();
				Reset_Mode();
      }
    }
    break;
    
    case MODE_PSE:	//PSE - Programa��o sequencial
    {
      switch (Selection)
      {
				case 0:	// wait Selection
				{
					Select_Enter(); 	// wait first Selection
				}
				break;
				case 1:	// wait Remote Control
				{
					if (!Key_Selection.Active && RC_Frame.Edge)	// any RC pressed
					{
						// if CR already in Memory
						if (RCFrame_Address)	// yes
						{
							// not an error
							RC_Keys_Copy.byte |= (char)(Mem_RC_Keys & 0xf0); // include keys
							RC_Address = RCFrame_Address;
							Put_Address_on_Display(RC_Address);
							Mode_Time = TIME_10S;
							Selection = 2;		//next
							break;
						}
						// find a Zero'ed memory area
						RC_Address = FindPageZeroed(0);
						if (RC_Address)	// found free page
						{
							Put_Address_on_Display(RC_Address);
							Mode_Time = TIME_10S;
							Selection = 2;		//next
						}
						else		// not found free page
						{
							Put_Message_on_Display(ERROR_2);
							Set_Error();	// Selection = 4;
						}
					}
				}
				break;
				case 2:	// wait Selection 3sec
				{
					if (Key_Selection.Active_3s)	// Selection during 3secs
					{
						// if CR already in Memory
						//if (RCFrame_Address)	// yes
						//{
						//	RC_Address = RCFrame_Address;	// from frame evaluation
						//	Put_Address_on_Display (RC_Address);
						//	Set_Error();	// Selection = 4;
						//}
						//else		// OK to program
						{
							ProgramRemoteControl(RC_Address);
							Remove_RC_Info();
							Reset_Mode();
						}
					}
				}
				break;
				case 4:	// error
				{
					if (!Error_Time)
						Reset_Mode();
				}
				break;
				default:
				{}
				break;
      }
    }
    break;
    
    case MODE_BLO:	//bLO - Bloqueio de c�digo
    case MODE_LIB:	//Lib - Liberacao de c�digo
    {
      Check_Selection_and_Digit();
      Treat_Display_Page_Address();
      
      // if (Selection == 4)	// wait time for error show, already treated
      if (Selection == 5)	// check consistency
      {
	// if Mem is empty (no RC)
	if (!Display_DP[1])	// from Put_Address routine
	{
	  Put_Message_on_Display(ERROR_3);
	  Set_Error();
	  break;
	}
	// OK to block/release
	BlockRemoteControl(RC_Address);
	Reset_Mode();
      }
    }
    break;
    
    case MODE_AEC:	//AEC - Apagamento Endere��vel
    {
      Check_Selection_and_Digit();
      Treat_Display_Page_Address();
      
      // if (Selection == 4)	// wait time for error show, already treated
      if (Selection == 5)	// check consistency
      {
	// if Mem is empty (no RC)
	if (!Display_DP[1])	// from Put_Address routine
	{
	  Put_Message_on_Display(ERROR_3);
	  Set_Error();
	  break;
	}
	// OK to clear
	ClearRemoteControl(RC_Address);
	Remove_RC_Info();
	Reset_Mode();
      }
    }
    break;
    
    case MODE_ACO:	//ACO - Apagamento Completo
    {
      switch (Selection)
      {
	case 0:	// wait Selection
	{
	  Select_Enter(); 	// wait first Selection
	}
	break;
	case 1:	// wait Remote Control 3secs
	{
	  if (!Key_Selection.Active && RC_Frame.Active_3s)	// any RC pressed 3s
	  {
	    Put_Message_on_Display(MSG_ooo);
	    Mode_Time = TIME_10S;
	    Selection = 2;		//next
	  }
	}
	break;
	case 2:	// wait Selection 3sec
	{
	  if (Key_Selection.Active_3s)	// Selection during 3secs
	  {
	    for (RC_Address = RCONTROL_PAGE_QTTY-1; (sPageAddrtype)RC_Address >= 0; RC_Address--)
	    {
	      ClearRemoteControl(RC_Address);
	      Overpass_Display(RC_Address);
	    }
	    Remove_RC_Info();
	    Mode = MODE_INITIAL;
	    Reset_Mode();
	  }
	}
	break;
	default:
	{}
	break;
      }
    }
    break;
    
    case MODE_LOC:	//LOC - Localize RC position
    {
      switch (Selection)
      {
	case 0:	// wait Selection
	{
	  Select_Enter();	// wait first Selection
	}
	break;
	case 1:	// wait Remote Control
	{
	  if (!Key_Selection.Active && RC_Frame.Edge)	// any RC pressed
	  {
	    RC_Address = RCFrame_Address;	// from frame evaluation
	    if (RC_Address)			// already present
	      Put_Address_on_Display(RC_Address);
	    else
	      Put_Message_on_Display(MSG_DASH);
	    Mode_Time = TIME_10S;
	  }
	}
	break;
	default:
	{}
	break;
      }
    }
    break;
    default:
    {}
    break;
  }
}

void Select_Enter (void)
/*****************************************************************************
	FUNCTION     : Select_Enter ()
	DESCRIPTION  : According to Key_Selection pressed
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  if (Key_Selection.Edge)	//Selection pressed
  {
    Put_Message_on_Display(MSG_CR);
    Mode_Time = TIME_10S;
		Remove_RC_Info();	// Jan09'07 to avoid previous keys to be saved in PEC
    Selection = 1;		//next
  }
}
 
void Check_Selection_and_Digit (void)
/*****************************************************************************
	FUNCTION     : Check_Selection_and_Digit ()
	DESCRIPTION  : According to Key_Selection pressed
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  if (Selection < 4)	// only if selection 0,1,2,3
  {
    if (Key_Selection.Edge)	//Selection pressed now
    {
      Mode_Time = TIME_10S;
      Blink_Nothing();
      switch (Selection)
      {
				case 0:	
				{
					Put_Address_on_Display(RC_Address);	// first selection, with 000
					Remove_RC_Info();	// Jan09'07 to avoid previous keys to be saved in PEC
					goto defsel;
				}
				break;
				case 1:	
				{
					Blink_Area(DIGIT1);
					Selection = 2;
				}
				break;
				case 2:	
				{
					Blink_Area(DIGIT2);
					Selection = 3;
				}
				break;
				// case 3:
				default:		
				{
					defsel:
					Blink_Area(DIGIT0);
					Selection = 1;
				}
				break;
      }
    }
    if (Selection && Key_Selection.Active_3s)	//Selection =1,2,3 pressed during 3s
    {
      Blink_Nothing();	// stop blinking
      if (RC_Address == 0)
      {
				Put_Message_on_Display (ERROR_0);
				Set_Error();
				return;
      }
      else
      {
				Selection = 5;	// Accept confirmation
      }
    }
  }
  else
  {
    if (Selection == 4)	// wait time for error show
    {
      if (!Error_Time)
				Reset_Mode();
    }
  }
}

void Treat_Display_Page_Address (void)
/*****************************************************************************
	FUNCTION     : Treat_Display_Page_Address ()
	DESCRIPTION  : Incrementa o display para definir qual endere�o alterar
			e update do endereco no display
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  if (!Key_Selection.Active && RC_Frame.Edge)	// any RC pressed
  {
    switch (Selection)
    {
      case 0:
      { 
				return;	// Mode not selected yet; abort
      }
      break;
      case 1:
      { selinc:
				RC_Address += 1; // Unidade Digit
      }
      break;
      case 2:
      {
				RC_Address += 10; // Dezena Digit
      }
      break;
      case 3:
      {
				RC_Address += 100; // Centena Digit
      }
      break;
      default:	
      {
				return;	// Any other Selection, abort
      }
      break;
    }
    // in case of Selection 1, 2 or 3: check Address consistency
    Mode_Time = TIME_10S;	// refresh overflow time
    if (RC_Address >= RCONTROL_PAGE_QTTY)	// prohibited >=512
    {
      RC_Address -= 500;
      if (RC_Address > 99)
				RC_Address -= 100;
    }
    Put_Address_on_Display(RC_Address);	// put onto Display area
  }
}

void Put_Address_on_Display (unsigned int NumberHex)
/*****************************************************************************
	FUNCTION     : Put_Address_on_Display ()
	DESCRIPTION  : According to Hexa number converted from Display_Page
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  signed char i;
  Hexa_to_Decimal(NumberHex);	// Result into Decimal[0..2]
  for (i = 2; i >= 0; i--)
  {
    Display_Buffer[i] = Number_Table [Decimal[i]];
  }
  // Set Display_DP[1] (used Mem) and Display_DP[2] (blocked CR)
  LoadEE(NumberHex);	// into buffer
  if (Mem_RC_Used)
  {
    Display_DP[1] = 1; //1
    if (Mem_RC_Blocked)
      Display_DP[2] = 1; //1
    else
      Display_DP[2] = 0; //0
  }
  else
  {
    Display_DP[1] = 0; //0
    Display_DP[2] = 0; //0
  }
}

void Overpass_Display (unsigned int NumberHex)
/*****************************************************************************
	FUNCTION     : Overpass_Display ()
	DESCRIPTION  : According to Hexa number converted from Display_Page
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  signed char i;
  Hexa_to_Decimal(NumberHex);	// Result into Decimal[0..2]
  for (i = 2; i >= 0; i--)
  {
    Display_Output[i] = Number_Table [Decimal[i]];
  }
}

void Put_Message_on_Display (unsigned char mode)
/*****************************************************************************
	FUNCTION     : Put_Message_on_Display ()
	DESCRIPTION  : Message according to the new mode
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  char index;
  signed char j;
  index = (char)(mode*3);
  for (j = 2; j >=0; j--)
  {
    Display_Buffer[2-j] = Message_Table[index+j]; 
  }
  // Clear Display_DP[1] (used Mem) and Display_DP[2] (blocked CR)
  Display_DP[1] = 0; //0
  Display_DP[2] = 0; //0
}

void Wait_Scan (void)
/*****************************************************************************
	FUNCTION     : Wait_Scan ()
	DESCRIPTION  : Wait while not interrupt, and not Scan Time
		- Scan occurs each TIME_SCAN, based on Lite Timer Timebase1
		- Uses WFI to power saving
		- Triggered by any timer interruption 
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  while	(!Scan)		// still wait Scan Time
  {
    //Wfi();				// wait any int
  }
  Scan--;					// Scan time reached, getout
}

void Init_Vars (void)
/*****************************************************************************
	FUNCTION     : Init_Var ()
	DESCRIPTION  : Initialization of variables
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  ScanCount = NUM_SCAN;
  Switch2.Count = TIME_BOUNCE;
  Switch1.Count = TIME_BOUNCE;
  Display_Pointer = 0;
  Mode = MODE_INITIAL;
  Selection = 0;
  RC_Address = 0;
  Put_Address_on_Display(RC_Address);
  Display_Output[0] = 0; //0
  Display_Output[1] = 0; //0
  Display_Output[2] = 0; //0
  Display_Blink_Count = TIME_BLINK;
  Display_Blink = 0;
}

void Treat_Sensor (SensorType * sensor, _Bool Pin, uchar Time_Bounce)
/*****************************************************************************
	FUNCTION     : Treat_Sensor (unsigned char Pin, SensorType * sensor)
	DESCRIPTION  : Reading of Keys, sensors, 
	ARGUMENTS    : Sensor(type) sensor: counter and flags
		       _Bool Pin: input HW
	RETURN VALUE : None
        
        Input:	Var:		Meaning:
		sensor.Edge	(Negative Edge on input after Bounce)
		sensor.Active	(Level 0 on input after Bounce)
		Pin		Input active LOW
		Note: if the Input pin is Active HIGH, negate this pin when
		calling this routine. Ex: Treat_Sensor (&Key, !PA0);

*****************************************************************************/
{
  (*sensor).Edge = FALSE;
  if ((*sensor).Active != Pin)	// same status
  {
    (*sensor).Count = Time_Bounce;
  }
  else			// different status
  {
    if (--(*sensor).Count == 0)
    {
      if ((*sensor).Active)
      {
	(*sensor).Active = FALSE;
      }
      else
      {
	(*sensor).Active = TRUE;
	(*sensor).Edge = TRUE;
      }			
      (*sensor).Count = Time_Bounce;
    }
  }
  if ((*sensor).Edge)
  {
    (*sensor).Count_3s.byte.lo = (TIME_3S&0x00ff);
    (*sensor).Count_3s.byte.hi = (TIME_3S&0xff00)>>8;
  }
  if ((*sensor).Active)
  {	// Decreases timer
    if (!--(*sensor).Count_3s.word)
    {
      (*sensor).Active_3s = TRUE;
    }
  }
  else
    (*sensor).Active_3s = FALSE;
}

void Treat_Relay (void)
/*****************************************************************************
	FUNCTION     : Treat_Relay ()
	DESCRIPTION  : Relay is active during Relay_Time value
	ARGUMENTS    : None
	RETURN VALUE : None
*****************************************************************************/
{
  if	(Relay_Time)
  {
    Relay = TRUE;
    Relay_Time--;
		GPIO_WriteLow(GPIOD, GPIO_PIN_0);
  }
  else
    Relay = FALSE;
}
