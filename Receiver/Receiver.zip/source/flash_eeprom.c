/********************  (c) 2004 STMicroelectronics  **************************
*  Project   : Xflash_RC_V0						     *
*  Filename  : flash_eeprom.c						     *
*  Author    : Roberto Pieruci						     *
*                                                                            *
*  Compiler  : Cosmic ANSI-C						     *
*  CPU       : ST7FLITE							     *
*****************************  File Contents  ********************************
*									     *
*  IAP Flash and EEPROM programming routines for application		     *
*									     *
******************************  Description  *********************************
*                                                                            *
*                                                                            *
*                                                                            *
**************************  Update Information  ******************************
*									     *
*  Ed. Date      Own Modification					     *
*  --- --------- ---  -----------------------------------------------------  *
*  001 Aug/16/04 RCP creation						     *
*  002 Feb/15/05 RCP improved						     *
*****************************************************************************/

/*************************  General Include Files  **************************/
#include "stm8s_conf.h"
#include "user_defs.h"		// User definitions
/****************************************************************************/

/***********************  Application Include Files  ************************/     
#include "hw_setup.h"
#include "rcontrol_rx.h"
#define	FLASH_EEPROM
#include "flash_eeprom.h"
//#include "i2cm_drv.h"
#undef FLASH_EEPROM
/****************************************************************************/
extern unsigned char @near * PointerFlash;

#if FLASH_EE == 0	// True EEPROM used
void WriteEeprom (void)
/*****************************************************************************
	FUNCTION     : WriteEeprom ()
	DESCRIPTION  : Writes to an ammount of bytes sized BLOCK_EE_SIZE 
		inside a same sized Block of EEprom, addressed at *PointerFlash, 
		with the same ammount of Ram at BufferRam address. No need
		erasing block.
	ARGUMENTS    : None
	RETURN VALUE : None
	USES	     : *PointerFlash: address in a page to be written into;
		       local var
*****************************************************************************/
{	
unsigned char register j;
// copying area
for (j = 0; j < BLOCK_EE_SIZE; j++)     
	{
		*(PointerFlash+j) = BufferRam[j];		
	}
	FLASH_WaitForLastOperation(FLASH_MEMTYPE_DATA);
}
#endif

unsigned char CheckSum(void)	//rcp
/*****************************************************************************
	FUNCTION     : CheckSum ()
	DESCRIPTION  : Calculates Checksum of BufferRam[0..BLOCK_EE_SIZE-2] into a
								 4-bit lsb value. Them, the 4-bit MSb is got from 
								 BufferRam[BLOCK_EE_SIZE-1] is also added and merged.
	ARGUMENTS    : None 
	RETURN VALUE : char: CheckSum
	USES	     : BufferRam; local var
*****************************************************************************/
{
	signed char register j;
	unsigned char CheckSumValue;	//register 
	
	CheckSumValue = (char)(BufferRam[BLOCK_EE_SIZE-1] >> 4);	//MSB
	for(j = BLOCK_EE_SIZE-2; j >=0  ; j--)	//excluded CheckSumBuffer byte
	{
		CheckSumValue = (char)((BufferRam[j] + (BufferRam[j] >> 4) + CheckSumValue) & 0x0f);
	}
	CheckSumValue |= (char)(BufferRam[BLOCK_EE_SIZE-1] & 0xf0);	//MSB
	if(CheckSumValue == 0xFF)	// to avoid save 0xFF 
		CheckSumValue = 0xF0;	// put 0 at lower 4bits
	return CheckSumValue;
}

void SaveEE(PageAddrtype Page)
/*****************************************************************************
	FUNCTION     : SaveEE (PageAddrtype Page)
	DESCRIPTION  : Saves BufferRam contents to EE/FLASH page pointed by 
		Page index.
		CheckSum of BufferRam is calculated internally here.
		This byte must never be 0xff; in this case it will assume 0xf0. //rcp 
	ARGUMENTS    : Page- page index to the area to be written into
	RETURN VALUE : None
	USES	     : local var, WriteFlash (or WriteEeprom), CheckSum,
	               *PointerFlash
*****************************************************************************/
{
  PointerFlash = (char *)StoreArea[Page];	// points to Master page
  CheckSumBuffer = CheckSum();
  WriteEeprom(); 				// master page
	#if BACKUP_PAGE == 1			// required backup
		PointerFlash += EEPROM_MAIN_SIZE;	// points to Backup page
		WriteEeprom();				// backup page
	#endif
}

#if FLASH_EE == 0	// True EEPROM used
void ReadEeprom (void) 
/*****************************************************************************
	FUNCTION     : ReadEeprom (void)
	DESCRIPTION  : Reads an ammount of bytes sized BLOCK_EE_SIZE 
		from a same sized Block of Eeprom addressed at *PointerFlash, 
		into the same ammount of Ram at BufferRam address.
	ARGUMENTS    : None
	RETURN VALUE : None
	USES	     : *PointerFlash: address to be read from;
		       local var
*****************************************************************************/
{
  unsigned char register j;

  for (j = 0; j  < BLOCK_EE_SIZE; j++)      
    BufferRam[j] = *(PointerFlash+j);	// recover data from flash/eeprom 
}
#endif


char LoadEE (PageAddrtype Page)      
/*****************************************************************************
	FUNCTION     : LoadEE (unsigned char Page)
	DESCRIPTION  : Recovers contents of EE/FLASH page pointed by Page 
		index to BufferRam area.
		Then, consistency is checked by the checksum, calculated and
		compared to the last byte of the BufferRam.
		In case of Inconsistency of Master page, same procedure is 
		used to recover the Backup page.
	ARGUMENTS    : Page- page index to the area to be read from
	RETURN VALUE : char: False if inconsistency, TRUE otherwise.
		       BufferRam[0] to BufferRam[BLOCK_EE_SIZE-1]: data
	USES	     : local vars, ReadFlash, *PointerFlash
*****************************************************************************/
{
  #if FLASH_EE == 0	// True Eeprom
  {
    PointerFlash = (char *)StoreArea[Page];// Locate area in EEprom Master Block
    ReadEeprom();	//copy compare at master page
    if ( CheckSumBuffer == CheckSum() )
      return TRUE;
    #if BACKUP_PAGE == 1			// required backup
      PointerFlash += EEPROM_MAIN_SIZE; // Locate area in EEprom Backup
      ReadEeprom();	//copy compare at backup page
      if ( CheckSumBuffer == CheckSum() )
	return TRUE;
    #endif
    return FALSE;
  }
  #endif
}              

