/********************  (c) 2004 STMicroelectronics  **************************
*  Project   : 								     *
*  Filename  : flash_eeprom.h						     *
*  Author    : Roberto Pieruci						     *
*                                                                            *
*  Compiler  : Cosmic ANSI-C						     *
*  CPU       : ST7FLITE							     *
*****************************  File Contents  ********************************
*									     *
*  IAP Flash and EEPROM programming definitions for RC application	     *
*									     *
******************************  Description  *********************************
*                                                                            *
* It defines EE_FL_PAGE_QTTY = 256 pages of Flash, each page with lenght     * 
* FLASH_PAGE_SIZE of 4 bytes, structured by 1 block BLOCK_EE_SIZE size 4.    *
* These are MASTER pages. It does not define other 256 pages of Flash, same  *
* format as the previous ones. These are BACKUP pages.                       *
* Total Flash area used is 256*4*1 = 1024 bytes                              *
*                                                                            *
**************************  Update Information  ******************************
*									     *
*  Ed. Date      Own Modification					     *
*  --- --------- ---  -----------------------------------------------------  *
*  001 Aug/16/04 RCP creation						     *
*  002 Feb/15/05 RCP improved						     *
*****************************************************************************/

#ifdef	EXT	
	#undef EXT
#endif
#ifdef	LOCAL
	#undef LOCAL
#endif
#ifdef	FLASH_EEPROM	// Enter file name of the associated .c file here 
	#define EXT
	#define LOCAL
#else
	#define EXT extern
#endif

#ifdef LOCAL
/*****************************************************************************
*                 LOCAL (Variables, Constants & Defines)                     *
*****************************************************************************/

/*****************************************************************************
*                      LOCAL (Function Prototypes)                           *
*****************************************************************************/


/****************************************************************************/
#endif
#undef LOCAL

/*****************************************************************************
*                 GLOBAL (Variables, Constants & Defines)                    *
*****************************************************************************/

//#define FLASH_EE 2		// Defined using I2C External EEprom
//#define	FLASH_EE 1	// Defined using FLASH as IAP / virtual EEProm
#define FLASH_EE 0		// Defined using TRUE EEprom

#define EE_FL_PAGE_QTTY		RCONTROL_PAGE_QTTY	//64
  // quantity of pages of emulated Flash attending Remote Control needs
#define	FLASH_PAGE_SIZE		(RCONTROL_MEM_SIZE*1)	//RCONTROL_MEM_SIZE*1
  // Each emulated EE page is same size of Block, no endurance
/* 	Note: Must be 2^n format, but >= BLOCK_EE_SIZE*2. If = BLOCK_EE_SIZE,
	no Endurance increasing can be implemented.
	Note1: If greater than 32, BLOCK_EE_SIZE Must be 2^n format
	Note2: The above value must be placed into .lkf file, inside the ICP 
	Area definitions to reserve space JUST AFTER .text Segment definition. 
Example:
+spc .text=256		# ICP memory PAGE size is 8x16xbackup, using 16*2 backup pages
	Note2: In case of NOT using FLASH_EE (FLASH_EE def 0), use:
+spc .text=0		# ICP memory size is 0
*/

#define	BLOCK_EE_SIZE		RCONTROL_MEM_SIZE	//4
  // Each block of EE data is 4 bytes long attending Remote Control needs
/*	Note: Must be <= FLASH_PAGE_SIZE/2 and <= 32 (Flash Paging access). 
	If = BLOCK_EE_SIZE, no Endurance increasing can be implemented.
	Note1: if FLASH_PAGE_SIZE >32, then BLOCK_EE_SIZE Must be 2^n format.
	Note2: if using True EEPROM, BLOCK_EE_SIZE must be 2^n format  
*/
//#define BACKUP_PAGE	1	// If required backup pages as mirror
#define BACKUP_PAGE	0	// If NOT required backup pages as mirror

#ifndef PADDRTYPE
  #if (EE_FL_PAGE_QTTY > 128)
    typedef unsigned int	PageAddrtype;
    typedef signed int		sPageAddrtype;
  #else
    typedef unsigned char	PageAddrtype;
    typedef signed char		sPageAddrtype;
  #endif
  #define PADDRTYPE
#endif


#if FLASH_EE == 0	// True Internal EEprom
  typedef uchar FlashEEtype[BLOCK_EE_SIZE];
  EXT FlashEEtype StoreArea[EE_FL_PAGE_QTTY] @FLASH_DATA_START_PHYSICAL_ADDRESS;
  #if BACKUP_PAGE == 1	// required backup
    EXT FlashEEtype BackStoreArea[EE_FL_PAGE_QTTY] @(FLASH_DATA_START_PHYSICAL_ADDRESS+sizeof(StoreArea));
  #endif
  #define	EEPROM_MAIN_SIZE	EE_FL_PAGE_QTTY * BLOCK_EE_SIZE
#endif

//EXT unsigned char @near * PointerFlash;

// Buffer used as Data to be Saved/Load into/from Flash IAP
//EXT unsigned char @tiny BufferRam[BLOCK_EE_SIZE];	
#define BufferRam Buffer.Byte	// Buffer is declared inside rcontrol_rx.h

#define CheckSumBuffer	BufferRam[BLOCK_EE_SIZE-1]	// last Byte

/*****************************************************************************
*                       GLOBAL (Function Prototypes)                         *
*****************************************************************************/
#ifndef FLASH_EE	// need to be defined
  #error FLASH_EE must be defined 2, 1 or 0; error
#endif


#if FLASH_EE == 0		// TRUE EEPROM
  EXT void WriteEeprom (void);
  EXT void ReadEeprom (void);
#endif

EXT void SaveEE (PageAddrtype Page);
EXT char LoadEE (PageAddrtype Page);
EXT unsigned char CheckSum(void);
