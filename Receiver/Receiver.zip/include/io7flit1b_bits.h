/********************  (c) 2004 STMicroelectronics  **************************
*  Project   : any							     *
*  Filename  : io7flit1b_bits.h						     *
*  Author    : Roberto Pieruci						     *
*                                                                            *
*  Compiler  :  Cosmic ANSI-C                                                *
*  CPU       :  ST7FLITE1Bx						     *
*****************************  File Contents  ********************************
*									     *
*  General CPU BITS definitions						     *
*									     *
**************************  Update Information  ******************************
*									     *
*  Ed. Date      Own Modification					     *
*  --- --------- ---  -----------------------------------------------------  *
*  001 Aug/16/05 RCP creation						     *
*									     *
*****************************************************************************/

/***************************** PUBLIC DECLARATIONS **************************/

#ifndef IO7FLIT1B_BITS
#define IO7FLIT1B_BITS

/* ST7FLITE2x Register Bits Definitions */

volatile char_bit	Padr	@PADR;
#define	PA0	Padr.bit.bit0
#define PA1	Padr.bit.bit1
#define PA2	Padr.bit.bit2
#define	PA3	Padr.bit.bit3
#define PA4	Padr.bit.bit4
#define PA5	Padr.bit.bit5
#define PA6	Padr.bit.bit6
#define PA7	Padr.bit.bit7

volatile char_bit	Pbdr	@PBDR;
#define	PB0	Pbdr.bit.bit0
#define PB1	Pbdr.bit.bit1
#define PB2	Pbdr.bit.bit2
#define	PB3	Pbdr.bit.bit3
#define PB4	Pbdr.bit.bit4
#define PB5	Pbdr.bit.bit5
#define PB6	Pbdr.bit.bit6

volatile char_bit	Pcdr	@PCDR;
#define	PC0	Pcdr.bit.bit0
#define PC1	Pcdr.bit.bit1

volatile char_bit	Ltcsr2	@LTCSR2;
#define TB2F	Ltcsr2.bit.bit0
#define TB2IE	Ltcsr2.bit.bit1

volatile char_bit	Ltcsr1	@LTCSR1;
#define TB1F	Ltcsr1.bit.bit3
#define TB1IE	Ltcsr1.bit.bit4
#define TB	Ltcsr1.bit.bit5
#define ICF_LT	Ltcsr1.bit.bit6
#define ICIE_LT	Ltcsr1.bit.bit7

volatile char_bit	Atcsr	@ATCSR;
#define CMPIE	Atcsr.bit.bit0
#define OVFIE1	Atcsr.bit.bit1
#define OVF1	Atcsr.bit.bit2
#define CK0	Atcsr.bit.bit3
#define CK1	Atcsr.bit.bit4
#define ICIE_AT	Atcsr.bit.bit5
#define ICF_AT	Atcsr.bit.bit6

volatile char_bit	Pwmcr	@PWMCR;
#define OE0	Pwmcr.bit.bit0
#define OE1	Pwmcr.bit.bit2
#define OE2	Pwmcr.bit.bit4
#define OE3	Pwmcr.bit.bit6

volatile char_bit	Pwm0csr	@PWM0CSR;
#define CMPF0	Pwm0csr.bit.bit0
#define OP0	Pwm0csr.bit.bit1

volatile char_bit	Pwm1csr	@PWM1CSR;
#define CMPF1	Pwm1csr.bit.bit0
#define OP1	Pwm1csr.bit.bit1

volatile char_bit	Pwm2csr	@PWM2CSR;
#define CMPF2	Pwm2csr.bit.bit0
#define OP2	Pwm2csr.bit.bit1

volatile char_bit	Pwm3csr	@PWM3CSR;
#define CMPF3	Pwm3csr.bit.bit0
#define OP3	Pwm3csr.bit.bit1

volatile char_bit	Atcsr2	@ATCSR2;
#define	TRAN1	Atcsr2.bit.bit0
#define	TRAN2	Atcsr2.bit.bit1
#define	ENCNTR2	Atcsr2.bit.bit2
#define	OVF2	Atcsr2.bit.bit3
#define	OVFIE2	Atcsr2.bit.bit4
#define	ICS	Atcsr2.bit.bit5
#define	FORCE1	Atcsr2.bit.bit6
#define	FORCE0	Atcsr2.bit.bit7

volatile char_bit	Breakcr	@BREAKCR;
#define PWM0	Breakcr.bit.bit0
#define PWM1	Breakcr.bit.bit1
#define PWM2	Breakcr.bit.bit2
#define PWM3	Breakcr.bit.bit3
#define BPEN	Breakcr.bit.bit4
#define BA	Breakcr.bit.bit5
#define BREDGE	Breakcr.bit.bit6
#define BRSEL	Breakcr.bit.bit7

volatile char_bit	Vrefcr	@VREFCR;
#define	VR0	Vrefcr.bit.bit2
#define	VR1	Vrefcr.bit.bit3
#define	VR2	Vrefcr.bit.bit4
#define	VR3	Vrefcr.bit.bit5
#define	VCBGR	Vrefcr.bit.bit6
#define	VCEXT	Vrefcr.bit.bit7

volatile char_bit	Cmpcr	@CMPCR;
#define	CMPON	Cmpcr.bit.bit0
#define	COUT	Cmpcr.bit.bit1
#define	CMP	Cmpcr.bit.bit2
#define	COMPIE	Cmpcr.bit.bit3
#define	CMPIF	Cmpcr.bit.bit4
#define	CINV	Cmpcr.bit.bit5
#define	CHYST	Cmpcr.bit.bit7

volatile char_bit	Fcsr	@FCSR;
#define	PGM	Fcsr.bit.bit0
#define LAT	Fcsr.bit.bit1
//#define OPT	Fcsr.bit.bit2

volatile char_bit	Eecsr	@EECSR;
#define	E2PGM	Eecsr.bit.bit0
#define E2LAT	Eecsr.bit.bit1

volatile char_bit	Spicr	@SPICR;
#define	SPR0	Spicr.bit.bit0
#define SPR1	Spicr.bit.bit1
#define CPHA	Spicr.bit.bit2
#define	CPOL	Spicr.bit.bit3
#define MSTR	Spicr.bit.bit4
#define SPR2	Spicr.bit.bit5
#define SPE	Spicr.bit.bit6
#define SPIE	Spicr.bit.bit7

volatile char_bit	Spicsr	@SPICSR;
#define	SSI	Spicsr.bit.bit0
#define SSM	Spicsr.bit.bit1
#define SOD	Spicsr.bit.bit2
#define MODF	Spicsr.bit.bit4
#define OVR	Spicsr.bit.bit5
#define WCOL	Spicsr.bit.bit6
#define SPIF	Spicsr.bit.bit7

volatile char_bit	Adccsr	@ADCCSR;
#define	CH0	Adccsr.bit.bit0
#define CH1	Adccsr.bit.bit1
#define CH2	Adccsr.bit.bit2
#define ADON	Adccsr.bit.bit5
#define SPEED	Adccsr.bit.bit6
#define EOC	Adccsr.bit.bit7

volatile char_bit	Adcdrl	@ADCDRL;
#define AMPSEL	Adcdrl.bit.bit2
#define SLOW	Adcdrl.bit.bit3
#define AMPCAL	Adcdrl.bit.bit4

volatile char_bit	Mccsr	@MCCSR;
#define	SMS	Mccsr.bit.bit0
#define	MCO	Mccsr.bit.bit1

volatile char_bit	Sicsr	@SICSR;
#define	AVDIE	Sicsr.bit.bit0
#define AVDF	Sicsr.bit.bit1
#define LVDRF	Sicsr.bit.bit2
#define LOCKED	Sicsr.bit.bit3
#define WDGRF	Sicsr.bit.bit4
#define CR0	Sicsr.bit.bit5
#define CR1	Sicsr.bit.bit6
#define LOCK32	Sicsr.bit.bit7

volatile char_bit	Plltst	@PLLTST;
#define	PLLDIV2	Plltst.bit.bit7

/*volatile char_bit	Scisr	@SCISR;
#define	PE	Scisr.bit.bit0
#define FE	Scisr.bit.bit1
#define NF	Scisr.bit.bit2
#define	OR	Scisr.bit.bit3
#define IDLE	Scisr.bit.bit4
#define RDRF	Scisr.bit.bit5
#define TC	Scisr.bit.bit6
#define TDRE	Scisr.bit.bit7

volatile char_bit	Scicr1	@SCICR1;
#define	PIE	Scicr1.bit.bit0
#define PS	Scicr1.bit.bit1
#define PCE	Scicr1.bit.bit2
#define	WAKE	Scicr1.bit.bit3
#define M	Scicr1.bit.bit4
#define SCID	Scicr1.bit.bit5
#define T8	Scicr1.bit.bit6
#define R8	Scicr1.bit.bit7

volatile char_bit	Scicr2	@SCICR2;
#define	SBK	Scicr2.bit.bit0
#define RWU	Scicr2.bit.bit1
#define RE	Scicr2.bit.bit2
#define	TE	Scicr2.bit.bit3
#define ILIE	Scicr2.bit.bit4
#define RIE	Scicr2.bit.bit5
#define TCIE	Scicr2.bit.bit6
#define TIE	Scicr2.bit.bit7
*/

volatile char_bit	Awucsr	@AWUCSR;
#define	AWUEN	Awucsr.bit.bit0
#define AWUM	Awucsr.bit.bit1
#define AWUF	Awucsr.bit.bit2

#endif
/******************************** END OF FILE *******************************/
