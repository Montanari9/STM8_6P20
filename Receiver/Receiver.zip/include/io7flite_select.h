/********************  (c) 2004 STMicroelectronics  **************************
*  Project   : any							     *
*  Filename: io7flite_select.h						     * 
*									     *
*  CPU	     : ST7FLITE							     * 
*****************************  File Contents  ********************************
*									     *
*  CPU CHOICE OVER ST7FLITE FAMILIES					     *
*									     *
**************************  Update Information  ******************************
*                                                                            *
*  Ed. Date      Own Modification					     *
*  --- --------- --- ------------------------------------------------------  *
*  001  	 RCP Imported from Cosmic hst files			     *
*  002 Feb/15/05 RCP improved						     *
*****************************************************************************/

/*************************** CPU CHOICE DECLARATIONS ************************/

#define ST7FLITE1Bx

/************************* AUTOMATIC CPU INCLUDE FILES **********************/

#ifdef ST7FLITE1Bx
	#include "io7flit1B.h"
	#include "io7flit1B_bits.h"
	#include "timingsLit_setup.h"	// System Clock Setup
	#define START_RAM	0x80
	#define END_RAM	0x1ff
	#define STACK_SIZE	20
	#define TOTAL_RAM	(END_RAM-START_RAM+1-STACK_SIZE)// except hole
	#define HOLE_RAM_START	0x100	// For Lite1Bx
	#define HOLE_RAM_END	0x17f	// For Lite1Bx
	#define FLASH_START	0xf000
	#define	EEPROM_START	0x1000	// For Litex9
#endif
/******************************** END OF FILE *******************************/
