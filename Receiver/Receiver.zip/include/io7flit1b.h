/********************  (c) 2004 STMicroelectronics  **************************
*  Project   : any							     *
*  Filename: io7flit1b.h						     * 
*  Copyright (c) 2004 STMicroelectronics				     *
*									     *
*  CPU	     : ST7FLITE1Bx						     * 
*****************************  File Contents  ********************************
*									     *
*  IO DEFINITIONS FOR ST7FLITE3x FAMILIES				     *
*									     *
**************************  Update Information  ******************************
*                                                                            *
*  Ed. Date      Own Modification					     *
*  --- --------- --- ------------------------------------------------------  *
*  001 Aug/16/05 RCP Creation						     *
******************************************************************************/

/***************************** PUBLIC DECLARATIONS **************************/

#ifndef IO7FLIT1B
#define IO7FLIT1B

/*	PORTS section
 */
volatile char PADR      @0x00;	/* Port A Data Register */
volatile char PADDR     @0x01;	/* Port A Data Direction */
volatile char PAOR      @0x02;	/* Port A Option register */
volatile char PBDR      @0x03;	/* Port B Data Register */
volatile char PBDDR     @0x04;	/* Port B Data Direction */
volatile char PBOR      @0x05;	/* Port B Option Register */
volatile char PCDR      @0x06;	/* Port C Data Register */
volatile char PCDDR     @0x07;	/* Port C Data Direction */

/*	TIMER section
 */
volatile char LTCSR2    @0x08;	/* Lite Timer Control/Status Reg 2 */
volatile char LTARR     @0x09;	/* Lite Timer Auto Reload Register */
volatile char LTCNTR    @0x0a;	/* Lite Timer Counter Register */
volatile char LTCSR1    @0x0b;	/* Lite Timer Control/Status Reg 1 */
volatile char LTICR     @0x0c;	/* Lite Timer Input Capture Register */

volatile char ATCSR     @0x0d;	/* Timer Control/Status Register */
volatile int  CNTR1     @0x0e;	/* Counter Register 1 */
volatile char CNTR1H    @0x0e;	/* Counter Register 1 High */
volatile char CNTR1L    @0x0f;	/* Counter Register 1 Low */

volatile int  ATR1      @0x10;	/* Auto Reload Register 1 */
volatile char ATR1H     @0x10;	/* Auto Reload Register 1 High */
volatile char ATR1L     @0x11;	/* Auto Reload Register 1 Low */
volatile char PWMCR     @0x12;	/* PWM Output Control Register */
volatile char PWM0CSR   @0x13;	/* PWM 0 Control/Status Register */
volatile char PWM1CSR   @0x14;	/* PWM 1 Control/Status Register */
volatile char PWM2CSR   @0x15;	/* PWM 2 Control/Status Register */
volatile char PWM3CSR   @0x16;	/* PWM 3 Control/Status Register */

volatile int  DCR0      @0x17;	/* PWM 0 Duty Cycle Register */
volatile char DCR0H     @0x17;	/* PWM 0 Duty Cycle Register High */
volatile char DCR0L     @0x18;	/* PWM 0 Duty Cycle Register Low */
volatile int  DCR1      @0x19;	/* PWM 1 Duty Cycle Register */
volatile char DCR1H     @0x19;	/* PWM 1 Duty Cycle Register High */
volatile char DCR1L     @0x1a;	/* PWM 1 Duty Cycle Register Low */
volatile int  DCR2      @0x1b;	/* PWM 2 Duty Cycle Register */
volatile char DCR2H     @0x1b;	/* PWM 2 Duty Cycle Register High */
volatile char DCR2L     @0x1c;	/* PWM 2 Duty Cycle Register Low */
volatile int  DCR3      @0x1d;	/* PWM 3 Duty Cycle Register */
volatile char DCR3H     @0x1d;	/* PWM 3 Duty Cycle Register High */
volatile char DCR3L     @0x1e;	/* PWM 3 Duty Cycle Register Low */

volatile int  ATICR     @0x1f;	/* Input Capture Register */
volatile char ATICRH    @0x1f;	/* Input Capture Register High */
volatile char ATICRL    @0x20;	/* Input Capture Register Low */

volatile char ATCSR2    @0x21;	/* Timer Control/Status Register 2 */
volatile char BREAKCR   @0x22;	/* Break Control Register */
volatile int  ATR2      @0x23;	/* Auto Reload Register 2 */
volatile char ATR2H     @0x23;	/* Auto Reload Register 2 High */
volatile char ATR2L     @0x24;	/* Auto Reload Register 2 Low */
volatile char DTGR      @0x25;	/* Dead Time Generator Register */
volatile char BREAKEN   @0x26;	/* Break Enable Register */

/*	COMPARATOR/VREF section
 */
volatile char VREFCR    @0x2c;	/* Internal Voltage Reference Control Register */
volatile char CMPCR     @0x2d;	/* Comparator and Internal Reference Control Register */

/*	WATCHDOG/FLASH/EEPROM section
 */
volatile char WDGCR     @0x2e;	/* Watchdog Control Register */
volatile char FCSR      @0x2f;	/* Flash Control/Status Register */
volatile char EECSR     @0x30;	/* EEPROM Control/Status Register */

/*	SPI section
 */
volatile char SPIDR     @0x31;	/* SPI Data Register */
volatile char SPICR     @0x32;	/* SPI Control Register */
volatile char SPISR     @0x33;	/* SPI Status Register */
volatile char SPICSR    @0x33;	/* SPI Control Status Register */

/*	ADC section
 */
volatile char ADCCSR    @0x34;	/* ADC Control/Status Register */
volatile int  ADCDR     @0x35;	/* ADC Data Register */
volatile char ADCDRH    @0x35;	/* ADC Data Register High */
volatile char ADCDRL    @0x36;	/* ADC Amplifier + Data Reg Low */

/*	SYSTEM section
 */
volatile char EICR      @0x37;	/* Main Clock Control/Status Reg */
volatile char MCCSR     @0x38;	/* Main Clock Control/Status Reg */
volatile char RCCR      @0x39;	/* RC Oscillator Control Register */
volatile char SICSR     @0x3a;	/* Integrity Control/Status Reg */
volatile char PLLTST    @0x3b;	/* PLL Test Reg */
volatile char EISR      @0x3c;	/* External Interrupt Selection Reg */

/*	SCI section
 */
//volatile char SCISR     @0x40;	/* SCI Status Register */
//volatile char SCIDR     @0x41;	/* SCI Data Register */
//volatile char SCIBRR    @0x42;	/* SCI Baud Rate Register */
//volatile char SCICR1    @0x43;	/* SCI Control Register 1 */
//volatile char SCICR2    @0x44;	/* SCI Control Register 2 */
//volatile char SCIERPR   @0x46;	/* SCI Extended Receive Prescaler Register */
//volatile char SCIETPR   @0x47;	/* SCI Extended Transmit Prescaler Register */

/*	AWU section
 */
volatile char AWUPR     @0x49;	/* AWU Prescaler Register */
volatile char AWUCSR    @0x4a;	/* AWU Control/Status Register */

/*	ICD section
 */
volatile char DMCR      @0x4b;	/* DM Control Register */
volatile char DMSR      @0x4c;	/* DM Status Register */
volatile int  DMBK1     @0x4d;	/* DM Breakpoint Register 1 */
volatile char DMBK1H    @0x4d;	/* DM Breakpoint Register 1 High */
volatile char DMBK1L    @0x4e;	/* DM Breakpoint Register 1 Low */
volatile int  DMBK2     @0x4f;	/* DM Breakpoint Register 2 */
volatile char DMBK2H    @0x4f;	/* DM Breakpoint Register 2 High */
volatile char DMBK2L    @0x50;	/* DM Breakpoint Register 2 Low */
volatile char DMCR2     @0x51;	/* DM Control Register 2 */
 
/*	AutoCalibration section
 */
volatile int 	@near RCCR0		@0xdee0;	/* 1MHz at 5V */
volatile char @near RCCRH0	@0xdee0;	/* 1MHz at 5V */
volatile char @near RCCRL0	@0xdee1;	/* 1MHz at 5V */
volatile int	@near RCCR1		@0xdee2;	/* 1MHz at 3V */
volatile char @near RCCRH1	@0xdee2;	/* 1MHz at 3V */
volatile char @near RCCRL1	@0xdee3;	/* 1MHz at 3V */

#endif
/******************************** END OF FILE *******************************/
