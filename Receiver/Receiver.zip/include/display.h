/********************  (c) 2004 STMicroelectronics  **************************
*  Project   : 							     *
*  Filename  : display.h						     *
*  Author    : Roberto Pieruci						     *
*                                                                            *
*  Compiler  : Cosmic ANSI-C						     *
*  CPU       : ST7FLITE							     *
*****************************  File Contents  ********************************
*									     *
*  general setup definitions for the microcontroller 			     *
*									     *
******************************  Description  *********************************
*                                                                            *
*                                                                            *
*                                                                            *
**************************  Update Information  ******************************
*									     *
*  Ed. Date      Own Modification					     *
*  --- --------- ---  -----------------------------------------------------  *
*  001 Aug/16/04 RCP creation						     *
*  002 Feb/15/05 RCP improved						     *
*****************************************************************************/

#ifdef	EXT	
	#undef EXT
#endif
#ifdef	LOCAL
	#undef LOCAL
#endif
#ifdef	DISPLAY  	// Enter file name of the associated .c file here 
	#define EXT
	#define LOCAL
#else
	#define EXT extern
#endif

#ifdef LOCAL
/*****************************************************************************
*                 LOCAL (Variables, Constants & Defines)                     *
*****************************************************************************/
#define DISPLAY0_OUT	PA5_ODR //PB6
#define DISPLAY1_OUT	PA6_ODR //PB5
#define DISPLAY2_OUT	PB1_ODR //PC1
//EXT int Teste1;
EXT int F0;
EXT int F1;
EXT int F2;
// Segments Definition
#define DP	0b00010000	  //0b00010000 = 0b11101111
#define GG	0b00000001		//0b00000001 = 0b11111110
#define FF	0b00000010		//0b00000010 = 0b11111101
#define EE	0b00000100		//0b00000100 = 0b11111011
#define DD	0b00001000		//0b00001000 = 0b11110111
#define CC	0b00100000		//0b00100000 = 0b11011111
#define BB	0b01000000		//0b01000000 = 0b10111111
#define AA	0b10000000 		//0b10000000 = 0b01111111
// Letter Definitions
#define LETTER_A (AA|BB|CC|EE|FF|GG)//(0b00011000)//(AA|BB|CC|EE|FF|GG)
#define LETTER_B (CC|DD|EE|FF|GG)//(0b11010000)//(CC|DD|EE|FF|GG)
#define LETTER_C (AA|DD|EE|FF)//(0b01110001)//(AA|DD|EE|FF)
#define LETTER_E (AA|DD|EE|FF|GG)//(0b01110000)//(AA|DD|EE|FF|GG)
#define LETTER_L (DD|EE|FF)//(0b11110001)//(DD|EE|FF)
#define LETTER_N (CC|EE|GG)//(0b11011010)//(CC|EE|GG)
#define LETTER_O (AA|BB|CC|DD|EE|FF)//(0b00010001)//(AA|BB|CC|DD|EE|FF)
#define LETTER_P (AA|BB|EE|FF|GG)//(0b00111000)//(AA|BB|EE|FF|GG)
#define LETTER_R (EE|GG)//(0b11111010)//(EE|GG)
#define LETTER_I (EE|FF)//(0b11111001)//(EE|FF)
#define LETTER_S (AA|CC|DD|FF|GG)//(0b01010100)//(AA|CC|DD|FF|GG)
#define BLANK    (0)//(0b11111111)//(0)
#define CHAR_MIN (GG)//(0b11111110)//(GG)
#define CHAR_o	 (CC|DD|EE|GG)//(0b11010010)//(CC|DD|EE|GG)

// Number Definitions
#define NUMBER_0 (AA|BB|CC|DD|EE|FF)//(0b00010001)//(AA|BB|CC|DD|EE|FF)
#define NUMBER_1 (BB|CC)//(0b10011111)//(BB|CC)
#define NUMBER_2 (AA|BB|DD|EE|GG)//(0b00110010)//(AA|BB|DD|EE|GG)
#define NUMBER_3 (AA|BB|CC|DD|GG)//(0b00010110)//(AA|BB|CC|DD|GG)
#define NUMBER_4 (BB|CC|FF|GG)//(0b10011100)//(BB|CC|FF|GG)
#define NUMBER_5 (AA|CC|DD|FF|GG)//(0b01010100)//(AA|CC|DD|FF|GG)
#define NUMBER_6 (CC|DD|EE|FF|GG)//(0b11010000)//(CC|DD|EE|FF|GG)
#define NUMBER_7 (AA|BB|CC)//(0b00011111)//(AA|BB|CC)
#define NUMBER_8 (AA|BB|CC|DD|EE|FF|GG)//(0b00010000)//(AA|BB|CC|DD|EE|FF|GG)
#define NUMBER_9 (AA|BB|CC|FF|GG)//(0b00011100)//(AA|BB|CC|FF|GG)

EXT char const Number_Table [10] = 
{
  NUMBER_0,	//DIGITO 0
  NUMBER_1,	//DIGITO 1
  NUMBER_2,	//DIGITO 2
  NUMBER_3,	//DIGITO 3
  NUMBER_4,	//DIGITO 4
  NUMBER_5,	//DIGITO 5
  NUMBER_6,	//DIGITO 6
  NUMBER_7,	//DIGITO 7
  NUMBER_8,	//DIGITO 8
  NUMBER_9,	//DIGITO 9
};
EXT char const Message_Table [3*18] = // According to ModeTypes
{
  NUMBER_0, NUMBER_0, NUMBER_0,	//MODE_INITIAL, 0
  LETTER_P, LETTER_E, LETTER_C,	//MODE_PEC, 1
  LETTER_P, LETTER_S, LETTER_E, //MODE_PSE, 2
  LETTER_B, LETTER_L, LETTER_O, //MODE_BLO, 3
  LETTER_L, LETTER_I, LETTER_B, //MODE_LIB, 4
  LETTER_A, LETTER_E, LETTER_C, //MODE_AEC, 5
  LETTER_A, LETTER_C, LETTER_O, //MODE_ACO, 6
  LETTER_L, LETTER_O, LETTER_C, //MODE_LOC, 7
  LETTER_E, LETTER_R, NUMBER_0,	//ERROR_0, 8
  LETTER_E, LETTER_R, NUMBER_1,	//ERROR_1, 9
  LETTER_E, LETTER_R, NUMBER_2,	//ERROR_2, 10
  LETTER_E, LETTER_R, NUMBER_3,	//ERROR_3, 11
  LETTER_E, LETTER_R, NUMBER_4,	//ERROR_4, 12
  LETTER_E, LETTER_R, NUMBER_5,	//ERROR_5, 13
  CHAR_MIN, CHAR_MIN, CHAR_MIN,	//MSG_DASH, 14
  LETTER_C, LETTER_R, BLANK,	//MSG_CR, 15
  BLANK, BLANK, BLANK,		//MSG_BLK, 16
  CHAR_o, CHAR_o, CHAR_o	//MSG_ooo, 17
};

/*****************************************************************************
*                      LOCAL (Function Prototypes)                           *
*****************************************************************************/


/****************************************************************************/
#endif
#undef LOCAL
/*****************************************************************************
*                 GLOBAL (Variables, Constants & Defines)                    *
*****************************************************************************/
EXT char @near Number_Table [];
EXT char @near Message_Table [];
EXT char Display_Output[3];	// output prepared to scan with blink
EXT char Display_Buffer[3];	// output fixed value before blink
EXT char Display_DP[3];		// DP output fixed value before blink
EXT char Display_Pointer;	// points to display scan
EXT char Display_Blink_Count;	// time control for blinking
#define TIME_BLINK	(100000000/TIME_SCAN)	// 100msec, based on TIME_SCAN

EXT char Display_Blink;	// control for blinking
#define DIGIT0	0
#define DIGIT1	1
#define DIGIT2	2
#define DP0	3
#define DP1	4
#define DP2	5
#define BLINK_STATUS	6
#define BLINK_ON	7

#define ERROR_0 (char)8
#define ERROR_1 (char)9
#define ERROR_2 (char)10
#define ERROR_3 (char)11
#define ERROR_4 (char)12
#define ERROR_5 (char)13
#define MSG_DASH (char)14
#define MSG_CR 	(char)15
#define MSG_BLK	(char)16
#define MSG_ooo	(char)17

EXT unsigned char Decimal [3];

/*****************************************************************************
*                       GLOBAL (Function Prototypes)                         *
*****************************************************************************/

EXT void Update_Display(void);
EXT void Scan_Display(void);
EXT void Hexa_to_Decimal(int Hexa);
#define Blink_Digits() Display_Blink |= (char) 0b10001111	//DP2 blink - 0b10001111
#define Blink_All() Display_Blink |= (char)0b10111111	//DP2 blink - 0b10111111
#define Blink_Area(BIT) Display_Blink |= (char)(0b10001000 | 1<<BIT)	//DP2 blink - 0b10001000 | 1<<BIT
#define Blink_Nothing() Display_Blink = (char)(Display_Blink & 0b11000000 | 0b10001000)	//DP2 blink - Display_Blink & 0b11000000 | 0b10001000)

