/********************  (c) 2004 STMicroelectronics  **************************
*  Project   : any							     *
*  Filename: io7fliteusx.h						     * 
*  Copyright (c) 2006 STMicroelectronics				     *
*									     *
*  CPU	     : ST7FLITEUSx						     * 
*****************************  File Contents  ********************************
*									     *
*  IO DEFINITIONS FOR ST7FLITE3x FAMILIES				     *
*									     *
**************************  Update Information  ******************************
*                                                                            *
*  Ed. Date      Own Modification					     *
*  --- --------- --- ------------------------------------------------------  *
*  001 May/25/06 RCP creation						     *
******************************************************************************/

/***************************** PUBLIC DECLARATIONS **************************/

#ifndef IO7FLITEUSX
#define IO7FLITEUSX

/*	PORTS section
 */
volatile char PADR      @0x00;	/* Port A Data Register */
volatile char PADDR     @0x01;	/* Port A Data Direction */
volatile char PAOR      @0x02;	/* Port A Option register */

/*	TIMER section
 */
volatile char LTCSR     @0x0b;	/* Lite Timer Control/Status Reg 1 */
volatile char LTICR     @0x0c;	/* Lite Timer Input Capture Register */

volatile char ATCSR     @0x0d;	/* Timer Control/Status Register */
volatile int  CNTR      @0x0e;	/* Counter Register */
volatile char CNTRH     @0x0e;	/* Counter Register High */
volatile char CNTRL    @0x0f;	/* Counter Register Low */

volatile int  ATR       @0x10;	/* Auto Reload Register */
volatile char ATRH      @0x10;	/* Auto Reload Register High */
volatile char ATRL      @0x11;	/* Auto Reload Register Low */
volatile char PWMCR     @0x12;	/* PWM Output Control Register */
volatile char PWM0CSR   @0x13;	/* PWM 0 Control/Status Register */

volatile int  DCR0      @0x17;	/* PWM 0 Duty Cycle Register */
volatile char DCR0H     @0x17;	/* PWM 0 Duty Cycle Register High */
volatile char DCR0L     @0x18;	/* PWM 0 Duty Cycle Register Low */

/*	FLASH section
 */
volatile char FCSR      @0x2f;	/* Flash Control/Status Register */

/*	ADC section
 */
volatile char ADCCSR    @0x34;	/* ADC Control/Status Register */
volatile int  ADCDR     @0x35;	/* ADC Data Register */
volatile char ADCDRH    @0x35;	/* ADC Data Register High */
volatile char ADCDRL    @0x36;	/* ADC Amplifier + Data Reg Low */

/*	SYSTEM section
 */
volatile char EICR1     @0x37;	/* External Interrupt Control Reg 1 */
volatile char MCCSR     @0x38;	/* Main Clock Control/Status Reg */
volatile char RCCR      @0x39;	/* RC Oscillator Control Register */
volatile char SICSR     @0x3a;	/* Integrity Control/Status Reg */
volatile char EICR2     @0x3d;	/* External Interrupt Control Reg 2 */
volatile char AVDTHCR   @0x3e;  /* AVD Threshold Selection Register */
volatile char CKCNTCSR  @0x3f;  /* Clock Controller Control/Status Reg */
volatile char MUXCR0    @0x47;	/* Mux IO-Reset Control Register 0 */
volatile char MUXCR1    @0x48;	/* Mux IO-Reset Control Register 1 */

/*	AWU section
 */
volatile char AWUPR     @0x49;	/* AWU Prescaler Register */
volatile char AWUCSR    @0x4a;	/* AWU Control/Status Register */

/*	ICD section
 */
volatile char DMCR      @0x4b;	/* DM Control Register */
volatile char DMSR      @0x4c;	/* DM Status Register */
volatile int  DMBK1     @0x4d;	/* DM Breakpoint Register 1 */
volatile char DMBK1H    @0x4d;	/* DM Breakpoint Register 1 High */
volatile char DMBK1L    @0x4e;	/* DM Breakpoint Register 1 Low */
volatile int  DMBK2     @0x4f;	/* DM Breakpoint Register 2 */
volatile char DMBK2H    @0x4f;	/* DM Breakpoint Register 2 High */
volatile char DMBK2L    @0x50;	/* DM Breakpoint Register 2 Low */
 
/*	AutoCalibration section
 */
volatile int 	@near RCCR0		@0xdee0;	/* 8MHz at 5V */
volatile char @near RCCRH0	@0xdee0;	/* 8MHz at 5V */
volatile char @near RCCRL0	@0xdee1;	/* 8MHz at 5V */
volatile int	@near RCCR1		@0xdee2;	/* 8MHz at 3V */
volatile char @near RCCRH1	@0xdee2;	/* 8MHz at 3V */
volatile char @near RCCRL1	@0xdee3;	/* 8MHz at 3V */

#endif
/******************************** END OF FILE *******************************/
