/********************  (c) 2004 STMicroelectronics  **************************
*  Project   : any							     *
*  Filename  : io7fliteusx_bits.h						     *
*  Author    : Roberto Pieruci						     *
*                                                                            *
*  Compiler  :  Cosmic ANSI-C                                                *
*  CPU       :  ST7FLITEUSx						     *
*****************************  File Contents  ********************************
*									     *
*  General CPU BITS definitions						     *
*									     *
**************************  Update Information  ******************************
*									     *
*  Ed. Date      Own Modification					     *
*  --- --------- ---  -----------------------------------------------------  *
*  001 May/25/06 RCP creation						     *
*									     *
*****************************************************************************/

/***************************** PUBLIC DECLARATIONS **************************/

#ifndef IO7FLITEUSX_BITS
#define IO7FLITEUSX_BITS

/* ST7FLITEUSX Register Bits Definitions */

volatile char_bit	Padr	@PADR;
#define	PA0	Padr.bit.bit0
#define PA1	Padr.bit.bit1
#define PA2	Padr.bit.bit2
#define	PA3	Padr.bit.bit3
#define PA4	Padr.bit.bit4
#define PA5	Padr.bit.bit5

volatile char_bit	Ltcsr	@LTCSR;
#define WDGD	Ltcsr.bit.bit0
#define WDGE	Ltcsr.bit.bit1
#define WDGRF	Ltcsr.bit.bit2
#define TBF		Ltcsr.bit.bit3
#define TBIE	Ltcsr.bit.bit4
#define TB		Ltcsr.bit.bit5
#define ICF		Ltcsr.bit.bit6
#define ICIE	Ltcsr.bit.bit7

volatile char_bit	Atcsr	@ATCSR;
#define CMPIE	Atcsr.bit.bit0
#define OVFIE	Atcsr.bit.bit1
#define OVF		Atcsr.bit.bit2
#define CK0		Atcsr.bit.bit3
#define CK1		Atcsr.bit.bit4

volatile char_bit	Pwmcr	@PWMCR;
#define OE0	Pwmcr.bit.bit0

volatile char_bit	Pwm0csr	@PWM0CSR;
#define CMPF0	Pwm0csr.bit.bit0
#define OP		Pwm0csr.bit.bit1

volatile char_bit	Fcsr	@FCSR;
#define	PGM	Fcsr.bit.bit0
#define LAT	Fcsr.bit.bit1
#define OPT	Fcsr.bit.bit2

volatile char_bit	Adccsr	@ADCCSR;
#define	CH0		Adccsr.bit.bit0
#define CH1		Adccsr.bit.bit1
#define CH2		Adccsr.bit.bit2
#define ADON	Adccsr.bit.bit5
#define SPEED	Adccsr.bit.bit6
#define EOC		Adccsr.bit.bit7

volatile char_bit	Adcdrl	@ADCDRL;
#define SLOW	Adcdrl.bit.bit3

volatile char_bit	Mccsr	@MCCSR;
#define	SMS	Mccsr.bit.bit0

volatile char_bit	Sicsr	@SICSR;
#define	AVDIE	Sicsr.bit.bit0
#define AVDF	Sicsr.bit.bit1
#define LVDRF	Sicsr.bit.bit2
#define CR0		Sicsr.bit.bit5
#define CR1		Sicsr.bit.bit6

volatile char_bit	Avdthcr	@AVDTHCR;
#define	AVD2	Avdthcr.bit.bit0
#define AVD1	Avdthcr.bit.bit1
#define CK0		Avdthcr.bit.bit5
#define CK1		Avdthcr.bit.bit6

volatile char_bit	Ckcntcsr	@CKCNTCSR;
#define	RC_AWU		Ckcntcsr.bit.bit0
#define RC_FLAG		Ckcntcsr.bit.bit2
#define AWU_FLAG	Ckcntcsr.bit.bit3

volatile char_bit	Awucsr	@AWUCSR;
#define	AWUEN	Awucsr.bit.bit0
#define AWUM	Awucsr.bit.bit1
#define AWUF	Awucsr.bit.bit2

#endif
/******************************** END OF FILE *******************************/
